package com.driveeasy.vehicule.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/** Propriétés métier externalisées dans le Config Server (vehicule-service.yml). */
@ConfigurationProperties(prefix = "driveeasy.vehicule")
public record VehiculeProperties(@DefaultValue("true") boolean seedEnabled,
                                 @DefaultValue("1990") int anneeMin) {
}
