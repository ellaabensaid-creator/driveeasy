package com.driveeasy.vehicule.config;

import com.driveeasy.vehicule.model.*;
import com.driveeasy.vehicule.repository.VehiculeRepository;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/** Jeu de données de démonstration chargé en mémoire au démarrage. */
@Component
public class DataInitializer implements ApplicationRunner {

    private final VehiculeRepository repository;
    private final VehiculeProperties props;

    public DataInitializer(VehiculeRepository repository, VehiculeProperties props) {
        this.repository = repository;
        this.props = props;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (!props.seedEnabled()) {
            return;
        }
        add("123 TUN 4567", "Renault", "Clio 5", 2022, "Blanc", Carburant.ESSENCE, Boite.MANUELLE, 5, 28000, "85.00", StatutVehicule.DISPONIBLE, CategorieVehicule.ECONOMIQUE);
        add("234 TUN 7788", "Peugeot", "208", 2023, "Rouge", Carburant.ESSENCE, Boite.MANUELLE, 5, 15000, "90.00", StatutVehicule.DISPONIBLE, CategorieVehicule.ECONOMIQUE);
        add("345 TUN 1020", "Volkswagen", "Golf 8", 2022, "Gris", Carburant.DIESEL, Boite.AUTOMATIQUE, 5, 41000, "120.00", StatutVehicule.LOUE, CategorieVehicule.COMPACTE);
        add("456 TUN 3344", "Toyota", "Corolla Hybrid", 2023, "Noir", Carburant.HYBRIDE, Boite.AUTOMATIQUE, 5, 22000, "140.00", StatutVehicule.DISPONIBLE, CategorieVehicule.BERLINE);
        add("567 TUN 9090", "Hyundai", "Tucson", 2021, "Bleu", Carburant.DIESEL, Boite.AUTOMATIQUE, 5, 55000, "180.00", StatutVehicule.DISPONIBLE, CategorieVehicule.SUV);
        add("678 TUN 2468", "Kia", "Sportage", 2024, "Blanc", Carburant.HYBRIDE, Boite.AUTOMATIQUE, 5, 9000, "200.00", StatutVehicule.DISPONIBLE, CategorieVehicule.SUV);
        add("789 TUN 1357", "Dacia", "Sandero", 2020, "Gris", Carburant.ESSENCE, Boite.MANUELLE, 5, 78000, "70.00", StatutVehicule.MAINTENANCE, CategorieVehicule.ECONOMIQUE);
        add("890 TUN 8642", "Mercedes", "Classe E", 2023, "Noir", Carburant.DIESEL, Boite.AUTOMATIQUE, 5, 18000, "320.00", StatutVehicule.DISPONIBLE, CategorieVehicule.LUXE);
    }

    private void add(String imm, String marque, String modele, int annee, String couleur, Carburant c, Boite b,
                     int places, int km, String prix, StatutVehicule statut, CategorieVehicule cat) {
        repository.save(Vehicule.builder().immatriculation(imm).marque(marque).modele(modele).annee(annee)
                .couleur(couleur).carburant(c).boite(b).nbPlaces(places).kilometrage(km)
                .prixJournalier(new BigDecimal(prix)).statut(statut).categorie(cat)
                .imageUrl("https://placehold.co/400x250?text=" + marque + "+" + modele.replace(' ', '+'))
                .build());
    }
}
