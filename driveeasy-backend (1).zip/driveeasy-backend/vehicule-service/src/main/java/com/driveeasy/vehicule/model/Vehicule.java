package com.driveeasy.vehicule.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/** Entité interne (jamais exposée directement par l'API). */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Vehicule {
    private Long id;
    private String immatriculation;
    private String marque;
    private String modele;
    private int annee;
    private String couleur;
    private Carburant carburant;
    private Boite boite;
    private int nbPlaces;
    private int kilometrage;
    private BigDecimal prixJournalier;
    private StatutVehicule statut;
    private CategorieVehicule categorie;
    private String imageUrl;
}
