package com.driveeasy.vehicule.model;

public enum CategorieVehicule {
    ECONOMIQUE, COMPACTE, BERLINE, SUV, LUXE
}
