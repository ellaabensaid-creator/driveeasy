package com.driveeasy.vehicule.service;

import com.driveeasy.vehicule.config.VehiculeProperties;
import com.driveeasy.vehicule.dto.StatutRequest;
import com.driveeasy.vehicule.dto.VehiculeRequest;
import com.driveeasy.vehicule.exception.ApiException;
import com.driveeasy.vehicule.model.Carburant;
import com.driveeasy.vehicule.model.CategorieVehicule;
import com.driveeasy.vehicule.model.StatutVehicule;
import com.driveeasy.vehicule.model.Vehicule;
import com.driveeasy.vehicule.repository.VehiculeRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Year;
import java.util.List;

@Service
public class VehiculeService {

    private final VehiculeRepository repository;
    private final VehiculeProperties props;

    public VehiculeService(VehiculeRepository repository, VehiculeProperties props) {
        this.repository = repository;
        this.props = props;
    }

    public List<Vehicule> rechercher(CategorieVehicule categorie, Carburant carburant,
                                     StatutVehicule statut, BigDecimal prixMax) {
        return repository.findAll().stream()
                .filter(v -> categorie == null || v.getCategorie() == categorie)
                .filter(v -> carburant == null || v.getCarburant() == carburant)
                .filter(v -> statut == null || v.getStatut() == statut)
                .filter(v -> prixMax == null || v.getPrixJournalier().compareTo(prixMax) <= 0)
                .toList();
    }

    public Vehicule trouver(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> ApiException.notFound("Véhicule introuvable : id=" + id));
    }

    public synchronized Vehicule creer(VehiculeRequest req) {
        verifierAnnee(req.annee());
        repository.findByImmatriculation(req.immatriculation()).ifPresent(v -> {
            throw ApiException.conflict("Immatriculation déjà utilisée : " + req.immatriculation());
        });
        Vehicule v = new Vehicule();
        appliquer(v, req);
        if (v.getStatut() == null) {
            v.setStatut(StatutVehicule.DISPONIBLE);
        }
        return repository.save(v);
    }

    public synchronized Vehicule modifier(Long id, VehiculeRequest req) {
        Vehicule v = trouver(id);
        verifierAnnee(req.annee());
        repository.findByImmatriculation(req.immatriculation())
                .filter(autre -> !autre.getId().equals(id))
                .ifPresent(autre -> {
                    throw ApiException.conflict("Immatriculation déjà utilisée : " + req.immatriculation());
                });
        appliquer(v, req);
        return repository.save(v);
    }

    public synchronized void supprimer(Long id) {
        Vehicule v = trouver(id);
        if (v.getStatut() == StatutVehicule.LOUE) {
            throw ApiException.conflict("Suppression refusée : le véhicule est actuellement loué");
        }
        repository.deleteById(id);
    }

    /** Utilisé par location-service (départ = LOUE, retour = DISPONIBLE + nouveau kilométrage). */
    public synchronized Vehicule changerStatut(Long id, StatutRequest req) {
        Vehicule v = trouver(id);
        if (req.kilometrage() != null) {
            if (req.kilometrage() < v.getKilometrage()) {
                throw ApiException.badRequest("Le nouveau kilométrage ne peut pas être inférieur à l'actuel ("
                        + v.getKilometrage() + ")");
            }
            v.setKilometrage(req.kilometrage());
        }
        v.setStatut(req.statut());
        return repository.save(v);
    }

    /**
     * Véhicules réservables : statut DISPONIBLE (un véhicule LOUE ou en MAINTENANCE ne peut pas être réservé).
     * Le chevauchement avec d'autres réservations est vérifié par location-service.
     */
    public List<Vehicule> disponibles(LocalDate dateDebut, LocalDate dateFin) {
        if (dateFin.isBefore(dateDebut)) {
            throw ApiException.badRequest("dateFin doit être postérieure ou égale à dateDebut");
        }
        return repository.findAll().stream().filter(v -> v.getStatut() == StatutVehicule.DISPONIBLE).toList();
    }

    private void verifierAnnee(int annee) {
        if (annee > Year.now().getValue() || annee < props.anneeMin()) {
            throw ApiException.badRequest("Année incohérente : doit être comprise entre "
                    + props.anneeMin() + " et " + Year.now().getValue());
        }
    }

    private void appliquer(Vehicule v, VehiculeRequest r) {
        v.setImmatriculation(r.immatriculation().trim());
        v.setMarque(r.marque());
        v.setModele(r.modele());
        v.setAnnee(r.annee());
        v.setCouleur(r.couleur());
        v.setCarburant(r.carburant());
        v.setBoite(r.boite());
        v.setNbPlaces(r.nbPlaces());
        v.setKilometrage(r.kilometrage());
        v.setPrixJournalier(r.prixJournalier());
        v.setCategorie(r.categorie());
        v.setImageUrl(r.imageUrl());
        if (r.statut() != null) {
            v.setStatut(r.statut());
        }
    }
}
