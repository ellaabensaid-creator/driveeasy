package com.driveeasy.vehicule.dto;

import com.driveeasy.vehicule.model.Boite;
import com.driveeasy.vehicule.model.CategorieVehicule;
import com.driveeasy.vehicule.model.Carburant;
import com.driveeasy.vehicule.model.StatutVehicule;
import com.driveeasy.vehicule.model.Vehicule;

import java.math.BigDecimal;

/** Objet renvoyé aux clients de l'API. */
public record VehiculeResponse(Long id, String immatriculation, String marque, String modele, int annee,
                               String couleur, Carburant carburant, Boite boite, int nbPlaces, int kilometrage,
                               BigDecimal prixJournalier, StatutVehicule statut, CategorieVehicule categorie,
                               String imageUrl) {

    public static VehiculeResponse from(Vehicule v) {
        return new VehiculeResponse(v.getId(), v.getImmatriculation(), v.getMarque(), v.getModele(), v.getAnnee(),
                v.getCouleur(), v.getCarburant(), v.getBoite(), v.getNbPlaces(), v.getKilometrage(),
                v.getPrixJournalier(), v.getStatut(), v.getCategorie(), v.getImageUrl());
    }
}
