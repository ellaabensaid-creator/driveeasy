package com.driveeasy.vehicule.exception;

import org.springframework.http.HttpStatus;

/** Exception métier portant le code HTTP à renvoyer. */
public class ApiException extends RuntimeException {
    private final HttpStatus status;

    public ApiException(HttpStatus status, String message) {
        super(message);
        this.status = status;
    }

    public ApiException(HttpStatus status, String message, Throwable cause) {
        super(message, cause);
        this.status = status;
    }

    public HttpStatus getStatus() { return status; }

    public static ApiException notFound(String message) { return new ApiException(HttpStatus.NOT_FOUND, message); }
    public static ApiException badRequest(String message) { return new ApiException(HttpStatus.BAD_REQUEST, message); }
    public static ApiException conflict(String message) { return new ApiException(HttpStatus.CONFLICT, message); }
    public static ApiException unavailable(String message, Throwable cause) {
        return new ApiException(HttpStatus.SERVICE_UNAVAILABLE, message, cause);
    }
}
