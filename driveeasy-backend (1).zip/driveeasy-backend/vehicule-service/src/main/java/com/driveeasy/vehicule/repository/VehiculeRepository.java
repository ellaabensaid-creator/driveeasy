package com.driveeasy.vehicule.repository;

import com.driveeasy.vehicule.model.Vehicule;
import org.springframework.stereotype.Repository;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/** Stockage en mémoire (RAM) : aucune base de données. */
@Repository
public class VehiculeRepository {

    private final Map<Long, Vehicule> store = new ConcurrentHashMap<>();
    private final AtomicLong sequence = new AtomicLong();

    public List<Vehicule> findAll() {
        return store.values().stream().sorted(Comparator.comparing(Vehicule::getId)).toList();
    }

    public Optional<Vehicule> findById(Long id) {
        return Optional.ofNullable(store.get(id));
    }

    public Optional<Vehicule> findByImmatriculation(String immatriculation) {
        return store.values().stream()
                .filter(v -> v.getImmatriculation().equalsIgnoreCase(immatriculation.trim()))
                .findFirst();
    }

    public Vehicule save(Vehicule vehicule) {
        if (vehicule.getId() == null) {
            vehicule.setId(sequence.incrementAndGet());
        }
        store.put(vehicule.getId(), vehicule);
        return vehicule;
    }

    public void deleteById(Long id) {
        store.remove(id);
    }
}
