# DriveEasy – Backend (microservices Spring Cloud)

Plateforme de location de véhicules : **Java 21 · Spring Boot 3.3 · Spring Cloud 2023.0 · Eureka · Config Server · Gateway · Zipkin**.
Les données sont stockées **uniquement en RAM** (aucune base de données).

## Architecture

| Composant | Dossier | Port |
|---|---|---|
| Service Registry (Eureka) | `service-registry` | 8761 |
| Config Server | `config-server` | 8888 |
| vehicule-service | `vehicule-service` | 8081 |
| client-service | `client-service` | 8082 |
| location-service | `location-service` | 8083 |
| API Gateway | `api-gateway` | 8080 |
| Zipkin (Docker) | `docker-compose.yml` | 9411 |
| Configuration centralisée | `config-repo` | – |

Le client ne parle qu'à la gateway : `http://localhost:8080/api/{vehicules|clients|locations}/...`

## Prérequis
JDK 21, Maven 3.9+, Docker (pour Zipkin).

## Installation et lancement (dans cet ordre)

```bash
# 0. compiler (depuis la racine) ; -DskipTests pour aller plus vite
mvn clean install

# 1. Zipkin
docker compose up -d

# 2. Service Registry  -> http://localhost:8761
mvn -pl service-registry spring-boot:run

# 3. Config Server (lit ./config-repo)   [nouveau terminal]
mvn -pl config-server spring-boot:run

# 4. Microservices métier                [un terminal par service]
mvn -pl vehicule-service spring-boot:run
mvn -pl client-service spring-boot:run
mvn -pl location-service spring-boot:run

# 5. API Gateway
mvn -pl api-gateway spring-boot:run
```
Vérifications : Eureka http://localhost:8761 (5 instances : config-server, vehicule-service, client-service, location-service, api-gateway), Zipkin http://localhost:9411, Config http://localhost:8888/vehicule-service/dev.

### Config Server : mode Git (GitHub)
Par défaut le Config Server lit le dossier local `config-repo`. Pour lire un dépôt GitHub :
1. pousser le **contenu** de `config-repo/` dans un dépôt GitHub (ex. `driveeasy-config`, branche `main`) ;
2. lancer : `CONFIG_SERVER_MODE=git CONFIG_GIT_URI=https://github.com/<user>/driveeasy-config mvn -pl config-server spring-boot:run`

### Profils
`dev` (par défaut, logs DEBUG) et `prod` (`SPRING_PROFILES_ACTIVE=prod`, échantillonnage Zipkin 10 %) – fichiers `application-dev.yml` / `application-prod.yml` du config-repo.

## Jeux de données (chargés au démarrage)
* 8 véhicules (id 3 = LOUE, id 7 = MAINTENANCE, les autres DISPONIBLE).
* 6 clients : 1 = VIP, 2 = FIDELE, 3 = STANDARD, **4 = permis expiré**, **5 = trop jeune (< 21 ans)**, 6 = STANDARD.
* 6 locations (3 terminées, 1 en cours sur le véhicule 3, 2 réservées).
Aucun compte de test (pas d'authentification dans ce prototype).

## API (via la gateway, port 8080)

| Service | Endpoints |
|---|---|
| vehicules | `GET /api/vehicules?categorie&carburant&statut&prixMax` · `GET /api/vehicules/{id}` · `POST` · `PUT /{id}` · `DELETE /{id}` · `PATCH /{id}/statut` · `GET /disponibles?dateDebut&dateFin` |
| clients | `GET /api/clients?q&nom&cin&email` · `GET /{id}` · `POST` · `PUT /{id}` · `DELETE /{id}` · `GET /{id}/eligibilite` · `PATCH /{id}/categorie` |
| locations | `GET /api/locations?statut&clientId&vehiculeId&dateDebut&dateFin&page&size` · `GET /{id}` · `POST` · `POST /simulation` · `PATCH /{id}/depart` · `PATCH /{id}/retour` · `PATCH /{id}/annulation` · `GET /statistiques` · `GET /vehicules-disponibles?dateDebut&dateFin` |

### Scénario de test (curl)
```bash
# simulation de prix (SUV, client VIP)
curl -X POST localhost:8080/api/locations/simulation -H 'Content-Type: application/json' \
  -d '{"clientId":1,"vehiculeId":5,"dateDebut":"2026-12-20","dateFinPrevue":"2026-12-23"}'

# réservation
curl -X POST localhost:8080/api/locations -H 'Content-Type: application/json' \
  -d '{"clientId":3,"vehiculeId":2,"dateDebut":"2026-12-20","dateFinPrevue":"2026-12-23"}'

# client non éligible -> 400
curl -X POST localhost:8080/api/locations -H 'Content-Type: application/json' \
  -d '{"clientId":4,"vehiculeId":2,"dateDebut":"2026-12-20","dateFinPrevue":"2026-12-23"}'

# départ, puis retour (id = celui renvoyé par la réservation)
curl -X PATCH localhost:8080/api/locations/7/depart
curl -X PATCH localhost:8080/api/locations/7/retour -H 'Content-Type: application/json' -d '{"kmRetour":15600}'

curl localhost:8080/api/locations/statistiques
```
Traces : exécuter `GET /api/locations/{id}` ou une création de location, puis ouvrir Zipkin (gateway → location-service → client-service / vehicule-service).

## Choix et hypothèses
* **Coefficient catégorie** = coefficient lié à la *catégorie du véhicule* (ECONOMIQUE 1.0 · COMPACTE 1.1 · BERLINE 1.2 · SUV 1.3 · LUXE 1.5), configurable dans `config-repo/location-service.yml`. `prixJournalierApplique = prixJournalier × coefficient` ; `montant = jours × prixJournalierApplique × (1 − remise)` ; `pénalité = 1,5 × prixJournalierApplique × jours de retard` (ajoutée au `montantTotal` au retour).
* Le véhicule porte donc un attribut `categorie` (nécessaire au filtre « catégorie » du cahier des charges).
* Pas de `datasource` externalisée (base de données interdite) : le Config Server externalise port, Eureka, Zipkin et les propriétés métier.
* `GET /vehicules/disponibles` filtre sur le statut ; le chevauchement entre réservations est vérifié par location-service (`GET /locations/vehicules-disponibles`, utilisé aussi à la création).
* Cohérence distribuée : au départ / retour, l'appel à vehicule-service est fait en premier ; si l'enregistrement local échoue, une **compensation** remet le véhicule dans son état précédent. Si un service distant est en panne → **503**.
* Codes HTTP : 200, 201, 204, 400 (validation / règle métier), 404, 409 (doublon, véhicule indisponible), 500, et 503 (service distant indisponible).
* Couche supplémentaire `service` entre Controller et Repository pour isoler les règles de gestion.

## Captures d'écran à ajouter (rapport / README)
Eureka (toutes les instances) · Config Server · Postman · Zipkin (trace gateway → location → client/vehicule).
