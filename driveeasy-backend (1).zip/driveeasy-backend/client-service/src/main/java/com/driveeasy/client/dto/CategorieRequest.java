package com.driveeasy.client.dto;

import com.driveeasy.client.model.CategorieClient;
import jakarta.validation.constraints.NotNull;

/** Corps du PATCH /clients/{id}/categorie. */
public record CategorieRequest(@NotNull CategorieClient categorie) {
}
