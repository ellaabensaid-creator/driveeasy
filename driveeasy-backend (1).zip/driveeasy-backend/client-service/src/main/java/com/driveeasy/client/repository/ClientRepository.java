package com.driveeasy.client.repository;

import com.driveeasy.client.model.Client;
import org.springframework.stereotype.Repository;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/** Stockage en mémoire (RAM). */
@Repository
public class ClientRepository {

    private final Map<Long, Client> store = new ConcurrentHashMap<>();
    private final AtomicLong sequence = new AtomicLong();

    public List<Client> findAll() {
        return store.values().stream().sorted(Comparator.comparing(Client::getId)).toList();
    }

    public Optional<Client> findById(Long id) {
        return Optional.ofNullable(store.get(id));
    }

    public Optional<Client> findByCin(String cin) {
        return store.values().stream().filter(c -> c.getCin().equals(cin)).findFirst();
    }

    public Optional<Client> findByEmail(String email) {
        return store.values().stream().filter(c -> c.getEmail().equalsIgnoreCase(email)).findFirst();
    }

    public Optional<Client> findByNumeroPermis(String numero) {
        return store.values().stream().filter(c -> c.getNumeroPermis().equalsIgnoreCase(numero)).findFirst();
    }

    public Client save(Client client) {
        if (client.getId() == null) {
            client.setId(sequence.incrementAndGet());
        }
        store.put(client.getId(), client);
        return client;
    }

    public void deleteById(Long id) {
        store.remove(id);
    }
}
