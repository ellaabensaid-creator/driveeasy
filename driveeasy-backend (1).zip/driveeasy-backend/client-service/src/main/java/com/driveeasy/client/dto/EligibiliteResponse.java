package com.driveeasy.client.dto;

import com.driveeasy.client.model.CategorieClient;

/** Résultat du contrôle d'éligibilité (âge >= 21 ans et permis non expiré). */
public record EligibiliteResponse(Long clientId, boolean eligible, int age, boolean permisValide,
                                  String message, CategorieClient categorieClient) {
}
