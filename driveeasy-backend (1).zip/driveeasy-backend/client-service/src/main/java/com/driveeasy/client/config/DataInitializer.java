package com.driveeasy.client.config;

import com.driveeasy.client.model.CategorieClient;
import com.driveeasy.client.model.Client;
import com.driveeasy.client.repository.ClientRepository;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

/** Jeu de données de démonstration (en mémoire). */
@Component
public class DataInitializer implements ApplicationRunner {

    private final ClientRepository repository;
    private final ClientProperties props;

    public DataInitializer(ClientRepository repository, ClientProperties props) {
        this.repository = repository;
        this.props = props;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (!props.seedEnabled()) {
            return;
        }
        LocalDate today = LocalDate.now();
        add("09876543", "Ben Salah", "Ahmed", today.minusYears(35), "ahmed.bensalah@mail.tn", "20111222", "Tunis", "P-100001", today.plusYears(4), CategorieClient.VIP);
        add("08765432", "Trabelsi", "Sarra", today.minusYears(28), "sarra.trabelsi@mail.tn", "21222333", "Sfax", "P-100002", today.plusYears(2), CategorieClient.FIDELE);
        add("07654321", "Gharbi", "Mohamed", today.minusYears(41), "m.gharbi@mail.tn", "22333444", "Sousse", "P-100003", today.plusYears(1), CategorieClient.STANDARD);
        add("06543210", "Jlassi", "Ines", today.minusYears(30), "ines.jlassi@mail.tn", "23444555", "Nabeul", "P-100004", today.minusMonths(2), CategorieClient.STANDARD);   // permis expiré
        add("05432109", "Mejri", "Yassine", today.minusYears(19), "yassine.mejri@mail.tn", "24555666", "Bizerte", "P-100005", today.plusYears(5), CategorieClient.STANDARD);   // trop jeune
        add("04321098", "Hamdi", "Amal", today.minusYears(26), "amal.hamdi@mail.tn", "25666777", "Ariana", "P-100006", today.plusYears(3), CategorieClient.STANDARD);
    }

    private void add(String cin, String nom, String prenom, LocalDate naissance, String email, String tel,
                     String adresse, String permis, LocalDate expiration, CategorieClient categorie) {
        repository.save(Client.builder().cin(cin).nom(nom).prenom(prenom).dateNaissance(naissance).email(email)
                .telephone(tel).adresse(adresse).numeroPermis(permis).dateExpirationPermis(expiration)
                .categorieClient(categorie).dateInscription(LocalDate.now().minusMonths(6)).build());
    }
}
