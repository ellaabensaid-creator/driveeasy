package com.driveeasy.client.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/** Propriétés métier externalisées (client-service.yml). */
@ConfigurationProperties(prefix = "driveeasy.client")
public record ClientProperties(@DefaultValue("true") boolean seedEnabled,
                               @DefaultValue("21") int ageMinimum) {
}
