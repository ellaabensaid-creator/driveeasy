package com.driveeasy.client.controller;

import com.driveeasy.client.dto.CategorieRequest;
import com.driveeasy.client.dto.ClientRequest;
import com.driveeasy.client.dto.ClientResponse;
import com.driveeasy.client.dto.EligibiliteResponse;
import com.driveeasy.client.service.ClientService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/clients")
public class ClientController {

    private final ClientService service;

    public ClientController(ClientService service) {
        this.service = service;
    }

    @GetMapping
    public List<ClientResponse> lister(@RequestParam(required = false) String q,
                                       @RequestParam(required = false) String nom,
                                       @RequestParam(required = false) String cin,
                                       @RequestParam(required = false) String email) {
        return service.rechercher(q, nom, cin, email).stream().map(ClientResponse::from).toList();
    }

    @GetMapping("/{id}")
    public ClientResponse detail(@PathVariable Long id) {
        return ClientResponse.from(service.trouver(id));
    }

    @PostMapping
    public ResponseEntity<ClientResponse> creer(@Valid @RequestBody ClientRequest req) {
        ClientResponse cree = ClientResponse.from(service.creer(req));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(cree.id()).toUri();
        return ResponseEntity.created(location).body(cree);   // 201
    }

    @PutMapping("/{id}")
    public ClientResponse modifier(@PathVariable Long id, @Valid @RequestBody ClientRequest req) {
        return ClientResponse.from(service.modifier(id, req));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> supprimer(@PathVariable Long id) {
        service.supprimer(id);
        return ResponseEntity.noContent().build();   // 204
    }

    /** Paramètre optionnel date : le permis doit être valide à cette date (ex. fin de location). */
    @GetMapping("/{id}/eligibilite")
    public EligibiliteResponse eligibilite(@PathVariable Long id,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return service.eligibilite(id, date);
    }

    @PatchMapping("/{id}/categorie")
    public ClientResponse changerCategorie(@PathVariable Long id, @Valid @RequestBody CategorieRequest req) {
        return ClientResponse.from(service.changerCategorie(id, req.categorie()));
    }
}
