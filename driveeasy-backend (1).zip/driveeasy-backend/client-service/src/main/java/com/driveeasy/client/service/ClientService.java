package com.driveeasy.client.service;

import com.driveeasy.client.config.ClientProperties;
import com.driveeasy.client.dto.ClientRequest;
import com.driveeasy.client.dto.EligibiliteResponse;
import com.driveeasy.client.exception.ApiException;
import com.driveeasy.client.model.CategorieClient;
import com.driveeasy.client.model.Client;
import com.driveeasy.client.repository.ClientRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

@Service
public class ClientService {

    private final ClientRepository repository;
    private final LocationClient locationClient;
    private final ClientProperties props;

    public ClientService(ClientRepository repository, LocationClient locationClient, ClientProperties props) {
        this.repository = repository;
        this.locationClient = locationClient;
        this.props = props;
    }

    /** q = recherche libre (nom, prénom, CIN, email) ; nom / cin / email = filtres précis. */
    public List<Client> rechercher(String q, String nom, String cin, String email) {
        return repository.findAll().stream()
                .filter(c -> q == null || q.isBlank() || contient(c.getNom(), q) || contient(c.getPrenom(), q)
                        || contient(c.getCin(), q) || contient(c.getEmail(), q))
                .filter(c -> nom == null || nom.isBlank() || contient(c.getNom(), nom) || contient(c.getPrenom(), nom))
                .filter(c -> cin == null || cin.isBlank() || contient(c.getCin(), cin))
                .filter(c -> email == null || email.isBlank() || contient(c.getEmail(), email))
                .toList();
    }

    public Client trouver(Long id) {
        return repository.findById(id).orElseThrow(() -> ApiException.notFound("Client introuvable : id=" + id));
    }

    public synchronized Client creer(ClientRequest req) {
        verifierUnicite(req, null);
        Client c = new Client();
        appliquer(c, req);
        c.setDateInscription(LocalDate.now());
        if (c.getCategorieClient() == null) {
            c.setCategorieClient(CategorieClient.STANDARD);
        }
        return repository.save(c);
    }

    public synchronized Client modifier(Long id, ClientRequest req) {
        Client c = trouver(id);
        verifierUnicite(req, id);
        appliquer(c, req);
        return repository.save(c);
    }

    public synchronized void supprimer(Long id) {
        trouver(id);
        if (locationClient.compterLocationsActives(id) > 0) {
            throw ApiException.conflict("Suppression refusée : le client a une location active");
        }
        repository.deleteById(id);
    }

    public synchronized Client changerCategorie(Long id, CategorieClient categorie) {
        Client c = trouver(id);
        c.setCategorieClient(categorie);
        return repository.save(c);
    }

    /** Éligible = âge >= 21 ans ET permis non expiré à la date donnée (aujourd'hui par défaut). */
    public EligibiliteResponse eligibilite(Long id, LocalDate date) {
        Client c = trouver(id);
        LocalDate reference = date != null ? date : LocalDate.now();
        int age = Period.between(c.getDateNaissance(), LocalDate.now()).getYears();
        boolean ageOk = age >= props.ageMinimum();
        boolean permisValide = !c.getDateExpirationPermis().isBefore(reference);
        String message;
        if (ageOk && permisValide) {
            message = "Client éligible à la location";
        } else if (!ageOk && !permisValide) {
            message = "Âge inférieur à " + props.ageMinimum() + " ans et permis expiré";
        } else if (!ageOk) {
            message = "Âge inférieur à " + props.ageMinimum() + " ans";
        } else {
            message = "Permis expiré (ou expirant avant la fin de la location) le " + c.getDateExpirationPermis();
        }
        return new EligibiliteResponse(c.getId(), ageOk && permisValide, age, permisValide, message, c.getCategorieClient());
    }

    private void verifierUnicite(ClientRequest req, Long idCourant) {
        conflit(repository.findByCin(req.cin()), idCourant, "CIN déjà utilisé : " + req.cin());
        conflit(repository.findByEmail(req.email()), idCourant, "Email déjà utilisé : " + req.email());
        conflit(repository.findByNumeroPermis(req.numeroPermis()), idCourant,
                "Numéro de permis déjà utilisé : " + req.numeroPermis());
    }

    private void conflit(Optional<Client> existant, Long idCourant, String message) {
        existant.filter(c -> !c.getId().equals(idCourant)).ifPresent(c -> {
            throw ApiException.conflict(message);
        });
    }

    private boolean contient(String valeur, String recherche) {
        return valeur != null && valeur.toLowerCase(Locale.ROOT).contains(recherche.trim().toLowerCase(Locale.ROOT));
    }

    private void appliquer(Client c, ClientRequest r) {
        c.setCin(r.cin());
        c.setNom(r.nom());
        c.setPrenom(r.prenom());
        c.setDateNaissance(r.dateNaissance());
        c.setEmail(r.email());
        c.setTelephone(r.telephone());
        c.setAdresse(r.adresse());
        c.setNumeroPermis(r.numeroPermis());
        c.setDateExpirationPermis(r.dateExpirationPermis());
        if (r.categorieClient() != null) {
            c.setCategorieClient(r.categorieClient());
        }
    }
}
