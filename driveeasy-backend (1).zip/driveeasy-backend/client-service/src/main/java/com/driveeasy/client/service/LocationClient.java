package com.driveeasy.client.service;

import com.driveeasy.client.exception.ApiException;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.util.Map;

/** Appel synchrone vers location-service (découvert via Eureka). */
@Component
public class LocationClient {

    private final RestClient rest;

    public LocationClient(RestClient.Builder builder) {
        this.rest = builder.baseUrl("http://location-service")
                .defaultStatusHandler(HttpStatusCode::isError, (req, res) -> {
                    throw new IllegalStateException("HTTP " + res.getStatusCode());
                })
                .build();
    }

    /** Nombre de locations actives (RESERVEE ou EN_COURS) d'un client. */
    public long compterLocationsActives(Long clientId) {
        try {
            Map<?, ?> body = rest.get()
                    .uri(u -> u.path("/locations/actives").queryParam("clientId", clientId).build())
                    .retrieve().body(Map.class);
            return body == null ? 0 : ((Number) body.get("count")).longValue();
        } catch (RestClientException | IllegalStateException e) {
            throw ApiException.unavailable("location-service indisponible : impossible de vérifier les locations actives", e);
        }
    }
}
