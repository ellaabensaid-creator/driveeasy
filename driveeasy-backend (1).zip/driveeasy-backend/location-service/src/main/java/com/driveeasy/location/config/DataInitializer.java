package com.driveeasy.location.config;

import com.driveeasy.location.model.Location;
import com.driveeasy.location.model.StatutLocation;
import com.driveeasy.location.repository.LocationRepository;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Jeu de données de démonstration, cohérent avec ceux de vehicule-service (véhicule 3 = LOUE)
 * et client-service (client 1 = VIP, client 2 = FIDELE).
 */
@Component
public class DataInitializer implements ApplicationRunner {

    private final LocationRepository repository;
    private final LocationProperties props;

    public DataInitializer(LocationRepository repository, LocationProperties props) {
        this.repository = repository;
        this.props = props;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (!props.seedEnabled()) {
            return;
        }
        LocalDate today = LocalDate.now();
        // terminées (alimentent le chiffre d'affaires et le top des véhicules)
        add(1L, 1L, today.minusDays(30), today.minusDays(27), today.minusDays(27), 28000, 28400, "85.00", "229.50", "0.00", StatutLocation.TERMINEE);
        add(2L, 4L, today.minusDays(20), today.minusDays(15), today.minusDays(14), 22000, 22900, "168.00", "756.00", "252.00", StatutLocation.TERMINEE);
        add(2L, 1L, today.minusDays(12), today.minusDays(10), today.minusDays(10), 28400, 28700, "85.00", "161.50", "0.00", StatutLocation.TERMINEE);
        // en cours : véhicule 3 (statut LOUE dans vehicule-service)
        add(3L, 3L, today.minusDays(3), today.plusDays(2), null, 41000, null, "132.00", "660.00", "0.00", StatutLocation.EN_COURS);
        // réservations futures
        add(6L, 5L, today.plusDays(5), today.plusDays(8), null, null, null, "234.00", "702.00", "0.00", StatutLocation.RESERVEE);
        add(1L, 8L, today.plusDays(10), today.plusDays(12), null, null, null, "480.00", "864.00", "0.00", StatutLocation.RESERVEE);
    }

    private void add(Long client, Long vehicule, LocalDate debut, LocalDate finPrevue, LocalDate retour,
                     Integer kmDepart, Integer kmRetour, String prixJour, String montant, String penalite,
                     StatutLocation statut) {
        repository.save(Location.builder().clientId(client).vehiculeId(vehicule).dateDebut(debut)
                .dateFinPrevue(finPrevue).dateRetourEffectif(retour).kmDepart(kmDepart).kmRetour(kmRetour)
                .prixJournalierApplique(new BigDecimal(prixJour)).montantTotal(new BigDecimal(montant))
                .penalite(new BigDecimal(penalite)).statut(statut).dateCreation(LocalDateTime.now().minusDays(35))
                .build());
    }
}
