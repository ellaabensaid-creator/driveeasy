package com.driveeasy.location.client;

import com.driveeasy.location.model.CategorieClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.time.LocalDate;

/** Appels synchrones vers client-service. */
@Component
public class ClientServiceClient extends AbstractRemoteClient {

    private final RestClient rest;

    public ClientServiceClient(RestClient.Builder builder) {
        super("client-service");
        this.rest = builder.baseUrl("http://client-service")
                .defaultStatusHandler(s -> s.isError(), (req, res) ->
                        traiterStatut(HttpStatus.valueOf(res.getStatusCode().value()), "Client"))
                .build();
    }

    public ClientDto getById(Long id) {
        return call(() -> rest.get().uri("/clients/{id}", id).retrieve().body(ClientDto.class));
    }

    /** GET /clients/{id}/eligibilite : le permis doit rester valide jusqu'à la date donnée. */
    public EligibiliteDto eligibilite(Long id, LocalDate dateFin) {
        return call(() -> rest.get()
                .uri(u -> u.path("/clients/{id}/eligibilite").queryParam("date", dateFin).build(id))
                .retrieve().body(EligibiliteDto.class));
    }

    /** PATCH /clients/{id}/categorie. */
    public void changerCategorie(Long id, CategorieClient categorie) {
        call(() -> {
            rest.patch().uri("/clients/{id}/categorie", id)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(new CategorieBody(categorie))
                    .retrieve().toBodilessEntity();
            return null;
        });
    }

    private record CategorieBody(CategorieClient categorie) {
    }
}
