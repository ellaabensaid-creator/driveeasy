package com.driveeasy.location.model;

public enum CategorieClient {
    STANDARD, FIDELE, VIP
}
