package com.driveeasy.location.controller;

import com.driveeasy.location.client.VehiculeDto;
import com.driveeasy.location.dto.*;
import com.driveeasy.location.model.StatutLocation;
import com.driveeasy.location.service.LocationService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/locations")
public class LocationController {

    private final LocationService service;

    public LocationController(LocationService service) {
        this.service = service;
    }

    @GetMapping
    public PageResponse<LocationResponse> lister(
            @RequestParam(required = false) StatutLocation statut,
            @RequestParam(required = false) Long clientId,
            @RequestParam(required = false) Long vehiculeId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateDebut,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFin,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return service.lister(statut, clientId, vehiculeId, dateDebut, dateFin, page, size);
    }

    @GetMapping("/statistiques")
    public StatistiquesResponse statistiques() {
        return service.statistiques();
    }

    /** Utilisé par client-service avant la suppression d'un client. */
    @GetMapping("/actives")
    public Map<String, Long> actives(@RequestParam Long clientId) {
        return Map.of("count", service.compterActives(clientId));
    }

    /** Véhicules réservables sur une période (statut + absence de chevauchement). */
    @GetMapping("/vehicules-disponibles")
    public List<VehiculeDto> vehiculesDisponibles(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateDebut,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFin) {
        return service.vehiculesDisponibles(dateDebut, dateFin);
    }

    @GetMapping("/{id}")
    public LocationDetailResponse detail(@PathVariable Long id) {
        return service.detail(id);
    }

    @PostMapping
    public ResponseEntity<LocationResponse> creer(@Valid @RequestBody LocationRequest req) {
        LocationResponse cree = LocationResponse.from(service.creer(req));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(cree.id()).toUri();
        return ResponseEntity.created(location).body(cree);   // 201
    }

    @PostMapping("/simulation")
    public SimulationResponse simuler(@Valid @RequestBody SimulationRequest req) {
        return service.simuler(req);
    }

    @PatchMapping("/{id}/depart")
    public LocationResponse depart(@PathVariable Long id) {
        return LocationResponse.from(service.demarrer(id));
    }

    @PatchMapping("/{id}/retour")
    public LocationResponse retour(@PathVariable Long id, @Valid @RequestBody RetourRequest req) {
        return LocationResponse.from(service.terminer(id, req));
    }

    @PatchMapping("/{id}/annulation")
    public LocationResponse annulation(@PathVariable Long id) {
        return LocationResponse.from(service.annuler(id));
    }
}
