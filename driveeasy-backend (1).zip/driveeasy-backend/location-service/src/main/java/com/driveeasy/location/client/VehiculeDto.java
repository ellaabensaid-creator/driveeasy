package com.driveeasy.location.client;

import com.driveeasy.location.model.CategorieVehicule;
import com.driveeasy.location.model.StatutVehicule;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;

/** Vue d'un véhicule telle que renvoyée par vehicule-service. */
@JsonIgnoreProperties(ignoreUnknown = true)
public record VehiculeDto(Long id, String immatriculation, String marque, String modele, Integer annee,
                          String couleur, Integer kilometrage, BigDecimal prixJournalier, StatutVehicule statut,
                          CategorieVehicule categorie, String imageUrl) {
}
