package com.driveeasy.location.client;

import com.driveeasy.location.model.CategorieClient;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.time.LocalDate;

/** Vue d'un client telle que renvoyée par client-service. */
@JsonIgnoreProperties(ignoreUnknown = true)
public record ClientDto(Long id, String cin, String nom, String prenom, String email, String telephone,
                        LocalDate dateExpirationPermis, CategorieClient categorieClient) {
}
