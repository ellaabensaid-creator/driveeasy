package com.driveeasy.location.service;

import com.driveeasy.location.client.ClientDto;
import com.driveeasy.location.client.ClientServiceClient;
import com.driveeasy.location.client.EligibiliteDto;
import com.driveeasy.location.client.VehiculeClient;
import com.driveeasy.location.client.VehiculeDto;
import com.driveeasy.location.dto.*;
import com.driveeasy.location.exception.ApiException;
import com.driveeasy.location.model.CategorieClient;
import com.driveeasy.location.model.Location;
import com.driveeasy.location.model.StatutLocation;
import com.driveeasy.location.model.StatutVehicule;
import com.driveeasy.location.repository.LocationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/** Cycle de vie d'une location + orchestration des appels vers vehicule-service et client-service. */
@Service
public class LocationService {

    private static final Logger log = LoggerFactory.getLogger(LocationService.class);
    private static final Set<StatutLocation> ACTIVES = EnumSet.of(StatutLocation.RESERVEE, StatutLocation.EN_COURS);

    private final LocationRepository repository;
    private final VehiculeClient vehicules;
    private final ClientServiceClient clients;
    private final TarifCalculator tarifs;

    public LocationService(LocationRepository repository, VehiculeClient vehicules,
                           ClientServiceClient clients, TarifCalculator tarifs) {
        this.repository = repository;
        this.vehicules = vehicules;
        this.clients = clients;
        this.tarifs = tarifs;
    }

    // ------------------------------------------------------------------ lecture

    public PageResponse<LocationResponse> lister(StatutLocation statut, Long clientId, Long vehiculeId,
                                                 LocalDate debut, LocalDate fin, int page, int size) {
        List<Location> filtrees = repository.findAll().stream()
                .filter(l -> statut == null || l.getStatut() == statut)
                .filter(l -> clientId == null || l.getClientId().equals(clientId))
                .filter(l -> vehiculeId == null || l.getVehiculeId().equals(vehiculeId))
                .filter(l -> debut == null || !l.getDateFinPrevue().isBefore(debut))   // chevauche la période
                .filter(l -> fin == null || !l.getDateDebut().isAfter(fin))
                .sorted(Comparator.comparing(Location::getId).reversed())
                .toList();
        int taille = Math.max(1, Math.min(size, 100));
        int pageCourante = Math.max(0, page);
        int from = Math.min(pageCourante * taille, filtrees.size());
        int to = Math.min(from + taille, filtrees.size());
        int totalPages = (int) Math.ceil(filtrees.size() / (double) taille);
        List<LocationResponse> contenu = filtrees.subList(from, to).stream().map(LocationResponse::from).toList();
        return new PageResponse<>(contenu, pageCourante, taille, filtrees.size(), totalPages);
    }

    public Location trouver(Long id) {
        return repository.findById(id).orElseThrow(() -> ApiException.notFound("Location introuvable : id=" + id));
    }

    /** Détail enrichi : client + véhicule agrégés (dégradé à null si le service distant est en panne). */
    public LocationDetailResponse detail(Long id) {
        Location l = trouver(id);
        ClientDto client = null;
        VehiculeDto vehicule = null;
        try {
            client = clients.getById(l.getClientId());
        } catch (ApiException e) {
            log.warn("Client {} non récupéré : {}", l.getClientId(), e.getMessage());
        }
        try {
            vehicule = vehicules.getById(l.getVehiculeId());
        } catch (ApiException e) {
            log.warn("Véhicule {} non récupéré : {}", l.getVehiculeId(), e.getMessage());
        }
        return new LocationDetailResponse(LocationResponse.from(l), client, vehicule);
    }

    public long compterActives(Long clientId) {
        return repository.findAll().stream()
                .filter(l -> l.getClientId().equals(clientId) && ACTIVES.contains(l.getStatut()))
                .count();
    }

    /** Véhicules DISPONIBLES (vehicule-service) sans réservation qui chevauche la période. */
    public List<VehiculeDto> vehiculesDisponibles(LocalDate debut, LocalDate fin) {
        if (!fin.isAfter(debut)) {
            throw ApiException.badRequest("dateFin doit être postérieure à dateDebut");
        }
        return vehicules.disponibles(debut, fin).stream()
                .filter(v -> !chevauche(v.id(), debut, fin))
                .toList();
    }

    // ------------------------------------------------------------------ simulation / création

    public SimulationResponse simuler(SimulationRequest req) {
        verifierDates(req.dateDebut(), req.dateFinPrevue(), false);
        VehiculeDto vehicule = vehicules.getById(req.vehiculeId());
        CategorieClient categorie = CategorieClient.STANDARD;
        if (req.clientId() != null) {
            ClientDto client = clients.getById(req.clientId());
            if (client.categorieClient() != null) {
                categorie = client.categorieClient();
            }
        }
        TarifCalculator.Tarif t = tarifs.calculer(vehicule, categorie, req.dateDebut(), req.dateFinPrevue());
        return new SimulationResponse(req.clientId(), vehicule.id(), t.jours(), t.prixJournalierBase(),
                vehicule.categorie(), t.coefficient(), t.prixJournalierApplique(), categorie,
                t.remisePourcentage(), t.montantTotal());
    }

    public synchronized Location creer(LocationRequest req) {
        verifierDates(req.dateDebut(), req.dateFinPrevue(), true);

        // 1) client éligible ? (appel client-service) - le permis doit couvrir toute la période
        EligibiliteDto eligibilite = clients.eligibilite(req.clientId(), req.dateFinPrevue());
        if (!eligibilite.eligible()) {
            throw ApiException.badRequest("Client non éligible : " + eligibilite.message());
        }

        // 2) véhicule disponible ? (appel vehicule-service)
        VehiculeDto vehicule = vehicules.getById(req.vehiculeId());
        if (vehicule.statut() != StatutVehicule.DISPONIBLE) {
            throw ApiException.conflict("Véhicule non réservable (statut : " + vehicule.statut() + ")");
        }
        if (chevauche(vehicule.id(), req.dateDebut(), req.dateFinPrevue())) {
            throw ApiException.conflict("Le véhicule est déjà réservé sur cette période");
        }

        // 3) calcul du prix et enregistrement
        TarifCalculator.Tarif t = tarifs.calculer(vehicule, eligibilite.categorieClient(),
                req.dateDebut(), req.dateFinPrevue());
        Location l = Location.builder()
                .clientId(req.clientId()).vehiculeId(req.vehiculeId())
                .dateDebut(req.dateDebut()).dateFinPrevue(req.dateFinPrevue())
                .prixJournalierApplique(t.prixJournalierApplique()).montantTotal(t.montantTotal())
                .penalite(BigDecimal.ZERO.setScale(2))
                .statut(StatutLocation.RESERVEE).dateCreation(LocalDateTime.now()).build();
        return repository.save(l);
    }

    // ------------------------------------------------------------------ départ / retour / annulation

    public synchronized Location demarrer(Long id) {
        Location l = trouver(id);
        if (l.getStatut() != StatutLocation.RESERVEE) {
            throw ApiException.conflict("Départ impossible : la location est " + l.getStatut());
        }
        VehiculeDto vehicule = vehicules.getById(l.getVehiculeId());
        if (vehicule.statut() != StatutVehicule.DISPONIBLE) {
            throw ApiException.conflict("Départ impossible : véhicule " + vehicule.statut());
        }
        // étape distante : si elle échoue (503), la location reste RESERVEE -> rien à compenser
        vehicules.changerStatut(l.getVehiculeId(), StatutVehicule.LOUE, null);
        try {
            l.setStatut(StatutLocation.EN_COURS);
            l.setKmDepart(vehicule.kilometrage());
            return repository.save(l);
        } catch (RuntimeException e) {
            // compensation : on libère le véhicule
            l.setStatut(StatutLocation.RESERVEE);
            l.setKmDepart(null);
            vehicules.changerStatut(l.getVehiculeId(), StatutVehicule.DISPONIBLE, null);
            throw e;
        }
    }

    public synchronized Location terminer(Long id, RetourRequest req) {
        Location l = trouver(id);
        if (l.getStatut() != StatutLocation.EN_COURS) {
            throw ApiException.conflict("Retour impossible : la location est " + l.getStatut());
        }
        LocalDate retour = req.dateRetourEffectif() != null ? req.dateRetourEffectif() : LocalDate.now();
        if (retour.isBefore(l.getDateDebut())) {
            throw ApiException.badRequest("La date de retour ne peut pas précéder la date de début");
        }
        if (req.kmRetour() < l.getKmDepart()) {
            throw ApiException.badRequest("kmRetour (" + req.kmRetour() + ") < kmDepart (" + l.getKmDepart() + ")");
        }
        BigDecimal penalite = tarifs.calculerPenalite(l.getPrixJournalierApplique(), l.getDateFinPrevue(), retour);
        BigDecimal montantInitial = l.getMontantTotal();

        // étape distante : véhicule de nouveau DISPONIBLE (+ nouveau kilométrage)
        vehicules.changerStatut(l.getVehiculeId(), StatutVehicule.DISPONIBLE, req.kmRetour());
        try {
            l.setStatut(StatutLocation.TERMINEE);
            l.setDateRetourEffectif(retour);
            l.setKmRetour(req.kmRetour());
            l.setPenalite(penalite);
            l.setMontantTotal(montantInitial.add(penalite));
            repository.save(l);
        } catch (RuntimeException e) {
            // compensation : le véhicule redevient LOUE et la location reste EN_COURS
            l.setStatut(StatutLocation.EN_COURS);
            l.setDateRetourEffectif(null);
            l.setKmRetour(null);
            l.setPenalite(BigDecimal.ZERO.setScale(2));
            l.setMontantTotal(montantInitial);
            vehicules.changerStatut(l.getVehiculeId(), StatutVehicule.LOUE, null);
            throw e;
        }
        mettreAJourCategorieClient(l.getClientId());
        return l;
    }

    public synchronized Location annuler(Long id) {
        Location l = trouver(id);
        if (l.getStatut() != StatutLocation.RESERVEE) {
            throw ApiException.conflict("Annulation impossible : seule une réservation peut être annulée (statut : "
                    + l.getStatut() + ")");
        }
        l.setStatut(StatutLocation.ANNULEE);
        return repository.save(l);
    }

    // ------------------------------------------------------------------ statistiques

    public StatistiquesResponse statistiques() {
        List<Location> toutes = repository.findAll();
        BigDecimal caTotal = BigDecimal.ZERO;
        BigDecimal caMois = BigDecimal.ZERO;
        YearMonth moisCourant = YearMonth.now();
        for (Location l : toutes) {
            if (l.getStatut() == StatutLocation.TERMINEE) {
                caTotal = caTotal.add(l.getMontantTotal());
                if (l.getDateRetourEffectif() != null && YearMonth.from(l.getDateRetourEffectif()).equals(moisCourant)) {
                    caMois = caMois.add(l.getMontantTotal());
                }
            }
        }

        // parc de véhicules (dégradé si vehicule-service est indisponible)
        List<VehiculeDto> parc = null;
        try {
            parc = vehicules.lister();
        } catch (ApiException e) {
            log.warn("Parc de véhicules indisponible pour les statistiques : {}", e.getMessage());
        }
        Map<Long, VehiculeDto> parcParId = parc == null ? Map.of()
                : parc.stream().collect(Collectors.toMap(VehiculeDto::id, Function.identity()));

        List<StatistiquesResponse.TopVehicule> top = toutes.stream()
                .filter(l -> l.getStatut() != StatutLocation.ANNULEE)
                .collect(Collectors.groupingBy(Location::getVehiculeId, Collectors.counting()))
                .entrySet().stream()
                .sorted(Map.Entry.<Long, Long>comparingByValue().reversed())
                .limit(5)
                .map(e -> {
                    VehiculeDto v = parcParId.get(e.getKey());
                    return new StatistiquesResponse.TopVehicule(e.getKey(),
                            v == null ? null : v.marque(), v == null ? null : v.modele(), e.getValue());
                }).toList();

        Integer total = null, dispo = null, loues = null, maintenance = null;
        Double taux = null;
        if (parc != null) {
            total = parc.size();
            dispo = (int) parc.stream().filter(v -> v.statut() == StatutVehicule.DISPONIBLE).count();
            loues = (int) parc.stream().filter(v -> v.statut() == StatutVehicule.LOUE).count();
            maintenance = (int) parc.stream().filter(v -> v.statut() == StatutVehicule.MAINTENANCE).count();
            taux = total == 0 ? 0.0 : Math.round(loues * 1000.0 / total) / 10.0;
        }
        return new StatistiquesResponse(caTotal.setScale(2, RoundingMode.HALF_UP), caMois.setScale(2, RoundingMode.HALF_UP),
                compter(toutes, StatutLocation.RESERVEE), compter(toutes, StatutLocation.EN_COURS),
                compter(toutes, StatutLocation.TERMINEE), compter(toutes, StatutLocation.ANNULEE),
                total, dispo, loues, maintenance, taux, top);
    }

    // ------------------------------------------------------------------ outils privés

    private long compter(List<Location> locations, StatutLocation statut) {
        return locations.stream().filter(l -> l.getStatut() == statut).count();
    }

    private void verifierDates(LocalDate debut, LocalDate fin, boolean interdirePasse) {
        if (!fin.isAfter(debut)) {
            throw ApiException.badRequest("dateFinPrevue doit être postérieure à dateDebut");
        }
        if (interdirePasse && debut.isBefore(LocalDate.now())) {
            throw ApiException.badRequest("dateDebut ne peut pas être dans le passé");
        }
    }

    /** Deux périodes se chevauchent si debut1 < fin2 et debut2 < fin1 (jour de remise = jour de départ autorisé). */
    private boolean chevauche(Long vehiculeId, LocalDate debut, LocalDate fin) {
        return repository.findAll().stream()
                .filter(l -> l.getVehiculeId().equals(vehiculeId) && ACTIVES.contains(l.getStatut()))
                .anyMatch(l -> debut.isBefore(l.getDateFinPrevue()) && l.getDateDebut().isBefore(fin));
    }

    /** FIDELE après 5 locations terminées, VIP après 15 (jamais de rétrogradation). */
    private void mettreAJourCategorieClient(Long clientId) {
        long terminees = repository.findAll().stream()
                .filter(l -> l.getClientId().equals(clientId) && l.getStatut() == StatutLocation.TERMINEE).count();
        CategorieClient cible = tarifs.categoriePour(terminees);
        try {
            CategorieClient actuelle = clients.getById(clientId).categorieClient();
            if (actuelle == null || cible.ordinal() > actuelle.ordinal()) {
                clients.changerCategorie(clientId, cible);
                log.info("Client {} passe en catégorie {} ({} locations terminées)", clientId, cible, terminees);
            }
        } catch (ApiException e) {
            // non bloquant : le retour du véhicule est déjà enregistré
            log.warn("Mise à jour de la catégorie du client {} impossible : {}", clientId, e.getMessage());
        }
    }
}
