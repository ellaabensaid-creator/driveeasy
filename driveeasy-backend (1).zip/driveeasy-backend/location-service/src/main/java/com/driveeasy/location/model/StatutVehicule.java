package com.driveeasy.location.model;

public enum StatutVehicule {
    DISPONIBLE, LOUE, MAINTENANCE
}
