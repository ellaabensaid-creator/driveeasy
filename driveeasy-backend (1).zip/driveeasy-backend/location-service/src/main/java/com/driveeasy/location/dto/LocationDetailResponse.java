package com.driveeasy.location.dto;

import com.driveeasy.location.client.ClientDto;
import com.driveeasy.location.client.VehiculeDto;

/** Location enrichie avec les données du client et du véhicule (agrégation inter-services). */
public record LocationDetailResponse(LocationResponse location, ClientDto client, VehiculeDto vehicule) {
}
