package com.driveeasy.location.exception;

import java.time.Instant;

/** Corps JSON standard des erreurs. */
public record ApiError(Instant timestamp, int status, String error, String message, String path) {}
