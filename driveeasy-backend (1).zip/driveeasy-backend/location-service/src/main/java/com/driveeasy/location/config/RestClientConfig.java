package com.driveeasy.location.config;

import io.micrometer.observation.ObservationRegistry;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.web.client.RestClient;

@Configuration
public class RestClientConfig {

    /**
     * RestClient avec load balancing (le nom du service Eureka sert d'hôte)
     * et observation activée pour propager le traceId vers Zipkin.
     */
    @Bean
    @LoadBalanced
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public RestClient.Builder loadBalancedRestClientBuilder(ObservationRegistry registry) {
        return RestClient.builder().observationRegistry(registry);
    }
}
