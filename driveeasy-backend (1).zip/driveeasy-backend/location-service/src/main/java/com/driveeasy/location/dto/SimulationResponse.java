package com.driveeasy.location.dto;

import com.driveeasy.location.model.CategorieClient;
import com.driveeasy.location.model.CategorieVehicule;

import java.math.BigDecimal;

public record SimulationResponse(Long clientId, Long vehiculeId, int jours, BigDecimal prixJournalierBase,
                                 CategorieVehicule categorieVehicule, BigDecimal coefficient,
                                 BigDecimal prixJournalierApplique, CategorieClient categorieClient,
                                 BigDecimal remisePourcentage, BigDecimal montantTotal) {
}
