package com.driveeasy.location.service;

import com.driveeasy.location.client.VehiculeDto;
import com.driveeasy.location.config.LocationProperties;
import com.driveeasy.location.exception.ApiException;
import com.driveeasy.location.model.CategorieClient;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Règles de tarification :
 *   prix journalier appliqué = prix journalier x coefficient de la catégorie du véhicule
 *   montant = jours x prix journalier appliqué x (1 - remise fidélité)
 *   pénalité = 1,5 x prix journalier appliqué x jours de retard
 */
@Component
public class TarifCalculator {

    private static final BigDecimal CENT = BigDecimal.valueOf(100);

    private final LocationProperties props;

    public TarifCalculator(LocationProperties props) {
        this.props = props;
    }

    public record Tarif(int jours, BigDecimal prixJournalierBase, BigDecimal coefficient,
                        BigDecimal prixJournalierApplique, BigDecimal remisePourcentage, BigDecimal montantTotal) {
    }

    public Tarif calculer(VehiculeDto vehicule, CategorieClient categorieClient, LocalDate debut, LocalDate fin) {
        int jours = (int) ChronoUnit.DAYS.between(debut, fin);
        if (jours < 1) {
            throw ApiException.badRequest("dateFinPrevue doit être postérieure à dateDebut");
        }
        BigDecimal coefficient = props.coefficientPour(String.valueOf(vehicule.categorie()));
        BigDecimal prixApplique = vehicule.prixJournalier().multiply(coefficient).setScale(2, RoundingMode.HALF_UP);
        BigDecimal remise = remisePour(categorieClient);
        BigDecimal facteur = BigDecimal.ONE.subtract(remise.divide(CENT, 4, RoundingMode.HALF_UP));
        BigDecimal montant = prixApplique.multiply(BigDecimal.valueOf(jours)).multiply(facteur)
                .setScale(2, RoundingMode.HALF_UP);
        return new Tarif(jours, vehicule.prixJournalier(), coefficient, prixApplique, remise, montant);
    }

    public BigDecimal calculerPenalite(BigDecimal prixJournalierApplique, LocalDate finPrevue, LocalDate retourEffectif) {
        long retard = ChronoUnit.DAYS.between(finPrevue, retourEffectif);
        if (retard <= 0) {
            return BigDecimal.ZERO.setScale(2);
        }
        return prixJournalierApplique.multiply(props.penaliteCoefficient())
                .multiply(BigDecimal.valueOf(retard)).setScale(2, RoundingMode.HALF_UP);
    }

    /** Catégorie de fidélité correspondant au nombre de locations terminées. */
    public CategorieClient categoriePour(long locationsTerminees) {
        if (locationsTerminees >= props.seuilVip()) {
            return CategorieClient.VIP;
        }
        if (locationsTerminees >= props.seuilFidele()) {
            return CategorieClient.FIDELE;
        }
        return CategorieClient.STANDARD;
    }

    private BigDecimal remisePour(CategorieClient categorie) {
        if (categorie == CategorieClient.VIP) {
            return props.remiseVip();
        }
        if (categorie == CategorieClient.FIDELE) {
            return props.remiseFidele();
        }
        return BigDecimal.ZERO;
    }
}
