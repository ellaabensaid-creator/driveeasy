package com.driveeasy.location.dto;

import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

/** clientId est optionnel : sans client, aucune remise de fidélité n'est appliquée. */
public record SimulationRequest(Long clientId, @NotNull Long vehiculeId,
                                @NotNull LocalDate dateDebut, @NotNull LocalDate dateFinPrevue) {
}
