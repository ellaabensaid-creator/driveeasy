package com.driveeasy.location.dto;

import java.math.BigDecimal;
import java.util.List;

public record StatistiquesResponse(BigDecimal chiffreAffairesTotal, BigDecimal chiffreAffairesMois,
                                   long locationsReservees, long locationsEnCours, long locationsTerminees,
                                   long locationsAnnulees, Integer vehiculesTotal, Integer vehiculesDisponibles,
                                   Integer vehiculesLoues, Integer vehiculesMaintenance, Double tauxOccupation,
                                   List<TopVehicule> topVehicules) {

    public record TopVehicule(Long vehiculeId, String marque, String modele, long nbLocations) {
    }
}
