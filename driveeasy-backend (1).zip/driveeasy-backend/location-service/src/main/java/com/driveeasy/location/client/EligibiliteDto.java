package com.driveeasy.location.client;

import com.driveeasy.location.model.CategorieClient;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record EligibiliteDto(Long clientId, boolean eligible, int age, boolean permisValide,
                             String message, CategorieClient categorieClient) {
}
