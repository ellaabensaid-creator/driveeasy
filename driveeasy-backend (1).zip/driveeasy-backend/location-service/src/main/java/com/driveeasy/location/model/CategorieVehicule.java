package com.driveeasy.location.model;

public enum CategorieVehicule {
    ECONOMIQUE, COMPACTE, BERLINE, SUV, LUXE
}
