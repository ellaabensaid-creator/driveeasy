package com.driveeasy.location.client;

import com.driveeasy.location.model.StatutVehicule;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.time.LocalDate;
import java.util.List;

/** Appels synchrones vers vehicule-service (résolu par Eureka + load balancer). */
@Component
public class VehiculeClient extends AbstractRemoteClient {

    private final RestClient rest;

    public VehiculeClient(RestClient.Builder builder) {
        super("vehicule-service");
        this.rest = builder.baseUrl("http://vehicule-service")
                .defaultStatusHandler(s -> s.isError(), (req, res) ->
                        traiterStatut(HttpStatus.valueOf(res.getStatusCode().value()), "Véhicule"))
                .build();
    }

    public VehiculeDto getById(Long id) {
        return call(() -> rest.get().uri("/vehicules/{id}", id).retrieve().body(VehiculeDto.class));
    }

    public List<VehiculeDto> lister() {
        return call(() -> rest.get().uri("/vehicules").retrieve()
                .body(new ParameterizedTypeReference<List<VehiculeDto>>() { }));
    }

    public List<VehiculeDto> disponibles(LocalDate debut, LocalDate fin) {
        return call(() -> rest.get()
                .uri(u -> u.path("/vehicules/disponibles").queryParam("dateDebut", debut).queryParam("dateFin", fin).build())
                .retrieve().body(new ParameterizedTypeReference<List<VehiculeDto>>() { }));
    }

    /** PATCH /vehicules/{id}/statut (kilométrage facultatif). */
    public void changerStatut(Long id, StatutVehicule statut, Integer kilometrage) {
        call(() -> {
            rest.patch().uri("/vehicules/{id}/statut", id)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(new StatutBody(statut, kilometrage))
                    .retrieve().toBodilessEntity();
            return null;
        });
    }

    private record StatutBody(StatutVehicule statut, Integer kilometrage) {
    }
}
