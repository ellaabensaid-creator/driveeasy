package com.driveeasy.location.client;

import com.driveeasy.location.exception.ApiException;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.RestClientException;

import java.util.function.Supplier;

/**
 * Gestion commune des erreurs distribuées :
 * 404 distant -> 404, autre 4xx -> 400/409, panne / 5xx / aucune instance Eureka -> 503.
 */
abstract class AbstractRemoteClient {

    private final String serviceName;

    protected AbstractRemoteClient(String serviceName) {
        this.serviceName = serviceName;
    }

    /** Convertit un statut HTTP d'erreur renvoyé par le service distant en ApiException. */
    protected void traiterStatut(HttpStatus status, String ressource) {
        if (status == HttpStatus.NOT_FOUND) {
            throw ApiException.notFound(ressource + " introuvable");
        } else if (status == HttpStatus.CONFLICT) {
            throw ApiException.conflict(serviceName + " : opération refusée (conflit)");
        } else if (status.is4xxClientError()) {
            throw ApiException.badRequest(serviceName + " : requête refusée (HTTP " + status.value() + ")");
        }
        throw new IllegalStateException(serviceName + " : HTTP " + status.value());
    }

    protected <T> T call(Supplier<T> action) {
        try {
            return action.get();
        } catch (ApiException e) {
            throw e;
        } catch (RestClientException | IllegalStateException e) {
            throw ApiException.unavailable(serviceName + " indisponible", e);
        }
    }
}
