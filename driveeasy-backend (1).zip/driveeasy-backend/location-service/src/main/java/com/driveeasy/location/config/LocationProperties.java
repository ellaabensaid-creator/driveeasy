package com.driveeasy.location.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

import java.math.BigDecimal;
import java.util.Map;
import java.util.TreeMap;

/** Propriétés métier externalisées (location-service.yml). */
@ConfigurationProperties(prefix = "driveeasy.location")
public record LocationProperties(@DefaultValue("true") boolean seedEnabled,
                                 @DefaultValue("1.5") BigDecimal penaliteCoefficient,
                                 @DefaultValue("5") BigDecimal remiseFidele,
                                 @DefaultValue("10") BigDecimal remiseVip,
                                 @DefaultValue("5") int seuilFidele,
                                 @DefaultValue("15") int seuilVip,
                                 Map<String, BigDecimal> coefficients) {

    /** Coefficient d'une catégorie de véhicule (1.0 si non configuré), insensible à la casse. */
    public BigDecimal coefficientPour(String categorie) {
        Map<String, BigDecimal> map = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        if (coefficients != null) {
            map.putAll(coefficients);
        }
        return map.getOrDefault(categorie, BigDecimal.ONE);
    }
}
