package com.driveeasy.location.service;

import com.driveeasy.location.client.VehiculeDto;
import com.driveeasy.location.config.LocationProperties;
import com.driveeasy.location.exception.ApiException;
import com.driveeasy.location.model.CategorieClient;
import com.driveeasy.location.model.CategorieVehicule;
import com.driveeasy.location.model.StatutVehicule;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class TarifCalculatorTest {

    private final LocationProperties props = new LocationProperties(false, new BigDecimal("1.5"),
            new BigDecimal("5"), new BigDecimal("10"), 5, 15, Map.of("SUV", new BigDecimal("1.30")));
    private final TarifCalculator calculator = new TarifCalculator(props);

    private VehiculeDto suv() {
        return new VehiculeDto(1L, "123 TUN 1", "Hyundai", "Tucson", 2022, "Bleu", 1000,
                new BigDecimal("100"), StatutVehicule.DISPONIBLE, CategorieVehicule.SUV, null);
    }

    @Test
    void montantAvecCoefficientEtRemiseFidele() {
        LocalDate debut = LocalDate.of(2026, 12, 1);
        TarifCalculator.Tarif t = calculator.calculer(suv(), CategorieClient.FIDELE, debut, debut.plusDays(3));
        // 3 jours x (100 x 1.30) x (1 - 5 %) = 370.50
        assertEquals(3, t.jours());
        assertEquals(new BigDecimal("370.50"), t.montantTotal());
    }

    @Test
    void penaliteDeRetard() {
        LocalDate fin = LocalDate.of(2026, 12, 4);
        // 2 jours de retard x 1,5 x 130.00 = 390.00
        assertEquals(new BigDecimal("390.00"),
                calculator.calculerPenalite(new BigDecimal("130.00"), fin, fin.plusDays(2)));
    }

    @Test
    void pasDePenaliteSansRetard() {
        LocalDate fin = LocalDate.of(2026, 12, 4);
        assertEquals(0, BigDecimal.ZERO.compareTo(
                calculator.calculerPenalite(new BigDecimal("130.00"), fin, fin.minusDays(1))));
    }

    @Test
    void periodeInvalideRefusee() {
        LocalDate d = LocalDate.of(2026, 12, 1);
        assertThrows(ApiException.class, () -> calculator.calculer(suv(), CategorieClient.STANDARD, d, d));
    }

    @Test
    void categorieSelonNombreDeLocations() {
        assertEquals(CategorieClient.STANDARD, calculator.categoriePour(4));
        assertEquals(CategorieClient.FIDELE, calculator.categoriePour(5));
        assertEquals(CategorieClient.VIP, calculator.categoriePour(15));
    }
}
