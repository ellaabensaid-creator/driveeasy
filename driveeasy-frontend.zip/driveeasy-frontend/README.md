# DriveEasy – Frontend (Angular 22)

Interface web pour les agents d'agence, consommant l'API **uniquement via l'API Gateway** (`http://localhost:8080/api`).
Angular 22 · composants standalone · signaux · formulaires réactifs · routes lazy-loaded · aucun framework UI externe.

## Prérequis
* Node.js ≥ 22 (testé avec Node 22) et npm
* Le backend `driveeasy-backend` démarré (au minimum : registry, config-server, les 3 services et la **gateway sur le port 8080**)

## Installation et lancement
```bash
npm install
npm start          # = ng serve  ->  http://localhost:4200
```
Autres commandes : `npm run build` (production, dossier `dist/`), `npm test` (tests unitaires).
L'URL de la gateway se change dans `src/app/core/api.ts` (`API_URL`). Le CORS du backend autorise `http://localhost:4200`.

## Écrans (cahier des charges §6.2)
| Écran | Route |
|---|---|
| Tableau de bord (KPI + graphiques) | `/dashboard` |
| Catalogue des véhicules (cartes, filtres, tri, pagination) | `/vehicules` |
| Formulaire véhicule (réactif + validations + statut) | `/vehicules/new`, `/vehicules/:id/edit` |
| Liste des clients (recherche, pagination, badges, alerte permis expiré) | `/clients` |
| Fiche client (infos, éligibilité, historique) | `/clients/:id` |
| Nouvelle location (assistant en 5 étapes) | `/locations/new` |
| Liste des locations (filtres statut / période, départ / retour / annulation) | `/locations` |
| Retour de véhicule (km, pénalités, récapitulatif imprimable) | `/locations/:id/retour` |

## Structure
```
src/app/
  core/    models.ts, api.ts, services (vehicule / client / location), error.interceptor.ts,
           pending-changes.guard.ts, notification.ts, date-utils.ts
  pages/   une page standalone par écran
  app.ts, app.routes.ts, app.config.ts
```
* **Intercepteur** `errorInterceptor` : affiche les messages d'erreur de l'API (400, 404, 409, 503…).
* **Guard** `pendingChangesGuard` : confirmation avant de quitter un formulaire véhicule modifié.
* Graphiques du tableau de bord réalisés en CSS (donut `conic-gradient` + barres) : aucune dépendance.

## Captures d'écran
Ajouter ici les captures de chaque écran (dossier `docs/`).
