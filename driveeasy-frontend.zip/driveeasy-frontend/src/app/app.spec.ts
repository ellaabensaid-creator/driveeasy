import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { App } from './app';
import { addDays, diffDays } from './core/date-utils';

describe('App', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [App], providers: [provideRouter([])] }).compileComponents();
  });

  it('should create the app and show the menu', async () => {
    const fixture = TestBed.createComponent(App);
    await fixture.whenStable();
    expect((fixture.nativeElement as HTMLElement).textContent).toContain('DriveEasy');
  });
});

describe('date-utils', () => {
  it('calcule les jours de retard', () => {
    expect(diffDays('2026-12-01', '2026-12-04')).toBe(3);
    expect(addDays('2026-12-30', 3)).toBe('2027-01-02');
  });
});
