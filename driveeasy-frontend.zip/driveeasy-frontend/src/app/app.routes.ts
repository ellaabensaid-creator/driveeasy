import { Routes } from '@angular/router';
import { pendingChangesGuard } from './core/pending-changes.guard';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
  { path: 'dashboard', title: 'Tableau de bord – DriveEasy', loadComponent: () => import('./pages/dashboard').then((m) => m.Dashboard) },
  { path: 'vehicules', title: 'Véhicules – DriveEasy', loadComponent: () => import('./pages/vehicule-catalogue').then((m) => m.VehiculeCatalogue) },
  { path: 'vehicules/new', title: 'Nouveau véhicule', canDeactivate: [pendingChangesGuard], loadComponent: () => import('./pages/vehicule-form').then((m) => m.VehiculeForm) },
  { path: 'vehicules/:id/edit', title: 'Modifier un véhicule', canDeactivate: [pendingChangesGuard], loadComponent: () => import('./pages/vehicule-form').then((m) => m.VehiculeForm) },
  { path: 'clients', title: 'Clients – DriveEasy', loadComponent: () => import('./pages/client-list').then((m) => m.ClientList) },
  { path: 'clients/:id', title: 'Fiche client', loadComponent: () => import('./pages/client-detail').then((m) => m.ClientDetail) },
  { path: 'locations', title: 'Locations – DriveEasy', loadComponent: () => import('./pages/location-list').then((m) => m.LocationList) },
  { path: 'locations/new', title: 'Nouvelle location', loadComponent: () => import('./pages/location-wizard').then((m) => m.LocationWizard) },
  { path: 'locations/:id/retour', title: 'Retour de véhicule', loadComponent: () => import('./pages/location-retour').then((m) => m.LocationRetour) },
  { path: '**', redirectTo: 'dashboard' },
];
