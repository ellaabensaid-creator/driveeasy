export type StatutVehicule = 'DISPONIBLE' | 'LOUE' | 'MAINTENANCE';
export type Carburant = 'ESSENCE' | 'DIESEL' | 'HYBRIDE' | 'ELECTRIQUE';
export type Boite = 'MANUELLE' | 'AUTOMATIQUE';
export type CategorieVehicule = 'ECONOMIQUE' | 'COMPACTE' | 'BERLINE' | 'SUV' | 'LUXE';
export type CategorieClient = 'STANDARD' | 'FIDELE' | 'VIP';
export type StatutLocation = 'RESERVEE' | 'EN_COURS' | 'TERMINEE' | 'ANNULEE';

export const CARBURANTS: Carburant[] = ['ESSENCE', 'DIESEL', 'HYBRIDE', 'ELECTRIQUE'];
export const BOITES: Boite[] = ['MANUELLE', 'AUTOMATIQUE'];
export const CATEGORIES_VEHICULE: CategorieVehicule[] = ['ECONOMIQUE', 'COMPACTE', 'BERLINE', 'SUV', 'LUXE'];
export const STATUTS_VEHICULE: StatutVehicule[] = ['DISPONIBLE', 'LOUE', 'MAINTENANCE'];
export const CATEGORIES_CLIENT: CategorieClient[] = ['STANDARD', 'FIDELE', 'VIP'];
export const STATUTS_LOCATION: StatutLocation[] = ['RESERVEE', 'EN_COURS', 'TERMINEE', 'ANNULEE'];

export interface Vehicule {
  id: number;
  immatriculation: string;
  marque: string;
  modele: string;
  annee: number;
  couleur: string;
  carburant: Carburant;
  boite: Boite;
  nbPlaces: number;
  kilometrage: number;
  prixJournalier: number;
  statut: StatutVehicule;
  categorie: CategorieVehicule;
  imageUrl: string;
}
export type VehiculeRequest = Omit<Vehicule, 'id'>;
/** Vue réduite renvoyée par GET /locations/vehicules-disponibles. */
export type VehiculeLite = Pick<Vehicule, 'id' | 'immatriculation' | 'marque' | 'modele' | 'annee' | 'couleur'
  | 'kilometrage' | 'prixJournalier' | 'statut' | 'categorie' | 'imageUrl'>;

export interface Client {
  id: number;
  cin: string;
  nom: string;
  prenom: string;
  dateNaissance: string;
  email: string;
  telephone: string;
  adresse: string;
  numeroPermis: string;
  dateExpirationPermis: string;
  categorieClient: CategorieClient;
  dateInscription: string;
  permisExpire: boolean;
}

export interface Eligibilite {
  clientId: number;
  eligible: boolean;
  age: number;
  permisValide: boolean;
  message: string;
  categorieClient: CategorieClient;
}

export interface Location {
  id: number;
  clientId: number;
  vehiculeId: number;
  dateDebut: string;
  dateFinPrevue: string;
  dateRetourEffectif: string | null;
  kmDepart: number | null;
  kmRetour: number | null;
  prixJournalierApplique: number;
  montantTotal: number;
  penalite: number;
  statut: StatutLocation;
  dateCreation: string;
}

export interface LocationDetail {
  location: Location;
  client: Pick<Client, 'id' | 'cin' | 'nom' | 'prenom' | 'email' | 'telephone' | 'categorieClient'> | null;
  vehicule: VehiculeLite | null;
}

export interface Page<T> {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
}

export interface Simulation {
  clientId: number | null;
  vehiculeId: number;
  jours: number;
  prixJournalierBase: number;
  categorieVehicule: CategorieVehicule;
  coefficient: number;
  prixJournalierApplique: number;
  categorieClient: CategorieClient;
  remisePourcentage: number;
  montantTotal: number;
}

export interface Statistiques {
  chiffreAffairesTotal: number;
  chiffreAffairesMois: number;
  locationsReservees: number;
  locationsEnCours: number;
  locationsTerminees: number;
  locationsAnnulees: number;
  vehiculesTotal: number | null;
  vehiculesDisponibles: number | null;
  vehiculesLoues: number | null;
  vehiculesMaintenance: number | null;
  tauxOccupation: number | null;
  topVehicules: { vehiculeId: number; marque: string | null; modele: string | null; nbLocations: number }[];
}
