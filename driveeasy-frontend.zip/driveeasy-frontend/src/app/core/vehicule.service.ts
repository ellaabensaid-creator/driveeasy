import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { API_URL, toParams } from './api';
import { Carburant, CategorieVehicule, StatutVehicule, Vehicule, VehiculeRequest } from './models';

export type VehiculeFilters = {
  categorie?: CategorieVehicule | '';
  carburant?: Carburant | '';
  statut?: StatutVehicule | '';
  prixMax?: number | null;
};

@Injectable({ providedIn: 'root' })
export class VehiculeService {
  private readonly http = inject(HttpClient);
  private readonly base = `${API_URL}/vehicules`;

  list(filters: VehiculeFilters = {}) {
    return this.http.get<Vehicule[]>(this.base, { params: toParams({ ...filters }) });
  }
  get(id: number) { return this.http.get<Vehicule>(`${this.base}/${id}`); }
  create(v: VehiculeRequest) { return this.http.post<Vehicule>(this.base, v); }
  update(id: number, v: VehiculeRequest) { return this.http.put<Vehicule>(`${this.base}/${id}`, v); }
  delete(id: number) { return this.http.delete<void>(`${this.base}/${id}`); }
}
