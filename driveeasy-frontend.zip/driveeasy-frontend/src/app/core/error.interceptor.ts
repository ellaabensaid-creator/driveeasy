import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { NotificationService } from './notification';

/**
 * Intercepteur d'erreurs : affiche le message renvoyé par l'API (format {status, message, path})
 * ou un message générique si la gateway est injoignable.
 */
export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const notifications = inject(NotificationService);
  return next(req).pipe(
    catchError((err: HttpErrorResponse) => {
      const message =
        err.status === 0
          ? 'API injoignable : vérifiez que la gateway (port 8080) est démarrée.'
          : (err.error?.message as string | undefined) ?? `Erreur HTTP ${err.status}`;
      notifications.error(message);
      return throwError(() => err);
    }),
  );
};
