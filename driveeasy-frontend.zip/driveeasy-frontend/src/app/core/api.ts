import { HttpParams } from '@angular/common/http';

/** URL de l'API Gateway : le frontend ne parle JAMAIS directement aux microservices. */
export const API_URL = 'http://localhost:8080/api';

type ParamValue = string | number | boolean | null | undefined;

/** Construit des HttpParams en ignorant les valeurs vides. */
export function toParams(obj: Record<string, ParamValue>): HttpParams {
  let params = new HttpParams();
  for (const [key, value] of Object.entries(obj)) {
    if (value !== null && value !== undefined && value !== '') {
      params = params.set(key, String(value));
    }
  }
  return params;
}
