import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { API_URL, toParams } from './api';
import { Location, LocationDetail, Page, Simulation, Statistiques, StatutLocation, VehiculeLite } from './models';

export type LocationFilters = {
  statut?: StatutLocation | '';
  clientId?: number | null;
  vehiculeId?: number | null;
  dateDebut?: string;
  dateFin?: string;
  page?: number;
  size?: number;
};

export interface LocationPayload {
  clientId: number;
  vehiculeId: number;
  dateDebut: string;
  dateFinPrevue: string;
}

@Injectable({ providedIn: 'root' })
export class LocationService {
  private readonly http = inject(HttpClient);
  private readonly base = `${API_URL}/locations`;

  list(filters: LocationFilters = {}) {
    return this.http.get<Page<Location>>(this.base, { params: toParams({ ...filters }) });
  }
  get(id: number) { return this.http.get<LocationDetail>(`${this.base}/${id}`); }
  create(p: LocationPayload) { return this.http.post<Location>(this.base, p); }
  simulate(p: Partial<LocationPayload> & { vehiculeId: number; dateDebut: string; dateFinPrevue: string }) {
    return this.http.post<Simulation>(`${this.base}/simulation`, p);
  }
  depart(id: number) { return this.http.patch<Location>(`${this.base}/${id}/depart`, {}); }
  retour(id: number, kmRetour: number, dateRetourEffectif?: string) {
    return this.http.patch<Location>(`${this.base}/${id}/retour`, { kmRetour, dateRetourEffectif });
  }
  annuler(id: number) { return this.http.patch<Location>(`${this.base}/${id}/annulation`, {}); }
  statistiques() { return this.http.get<Statistiques>(`${this.base}/statistiques`); }
  vehiculesDisponibles(dateDebut: string, dateFin: string) {
    return this.http.get<VehiculeLite[]>(`${this.base}/vehicules-disponibles`, { params: toParams({ dateDebut, dateFin }) });
  }
}
