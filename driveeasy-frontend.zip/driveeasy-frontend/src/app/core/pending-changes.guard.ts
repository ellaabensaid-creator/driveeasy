import { CanDeactivateFn } from '@angular/router';

export interface HasPendingChanges {
  hasPendingChanges(): boolean;
}

/** Guard : demande confirmation avant de quitter un formulaire modifié et non enregistré. */
export const pendingChangesGuard: CanDeactivateFn<HasPendingChanges> = (component) =>
  !component.hasPendingChanges() || confirm('Des modifications ne sont pas enregistrées. Quitter la page ?');
