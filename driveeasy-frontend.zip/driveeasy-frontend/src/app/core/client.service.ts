import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { API_URL, toParams } from './api';
import { CategorieClient, Client, Eligibilite } from './models';

@Injectable({ providedIn: 'root' })
export class ClientService {
  private readonly http = inject(HttpClient);
  private readonly base = `${API_URL}/clients`;

  list(q = '') { return this.http.get<Client[]>(this.base, { params: toParams({ q }) }); }
  get(id: number) { return this.http.get<Client>(`${this.base}/${id}`); }
  eligibilite(id: number, date?: string) {
    return this.http.get<Eligibilite>(`${this.base}/${id}/eligibilite`, { params: toParams({ date }) });
  }
  changerCategorie(id: number, categorie: CategorieClient) {
    return this.http.patch<Client>(`${this.base}/${id}/categorie`, { categorie });
  }
}
