import { DatePipe, DecimalPipe } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { ClientService } from '../core/client.service';
import { LocationService } from '../core/location.service';
import { NotificationService } from '../core/notification';
import { CATEGORIES_CLIENT, CategorieClient, Client, Eligibilite, Location, Vehicule } from '../core/models';
import { VehiculeService } from '../core/vehicule.service';

@Component({
  selector: 'app-client-detail',
  imports: [DatePipe, DecimalPipe, RouterLink, FormsModule],
  template: `
    <a routerLink="/clients" class="muted">← Retour aux clients</a>
    @if (client(); as c) {
      <div class="page-head">
        <h1>{{ c.prenom }} {{ c.nom }}</h1>
        <span class="badge big-badge" [class]="'cat-' + c.categorieClient">{{ c.categorieClient }}</span>
      </div>

      @if (c.permisExpire) { <div class="alert">⚠ Le permis de conduire de ce client a expiré le {{ c.dateExpirationPermis | date: 'dd/MM/yyyy' }}.</div> }

      <section class="grid2">
        <div class="card">
          <h3>Informations</h3>
          <dl class="dl">
            <dt>CIN</dt><dd>{{ c.cin }}</dd>
            <dt>Date de naissance</dt><dd>{{ c.dateNaissance | date: 'dd/MM/yyyy' }}</dd>
            <dt>Email</dt><dd>{{ c.email }}</dd>
            <dt>Téléphone</dt><dd>{{ c.telephone }}</dd>
            <dt>Adresse</dt><dd>{{ c.adresse }}</dd>
            <dt>N° de permis</dt><dd>{{ c.numeroPermis }}</dd>
            <dt>Expiration du permis</dt><dd [class.err]="c.permisExpire">{{ c.dateExpirationPermis | date: 'dd/MM/yyyy' }}</dd>
            <dt>Inscrit le</dt><dd>{{ c.dateInscription | date: 'dd/MM/yyyy' }}</dd>
          </dl>
          <label class="inline">Catégorie de fidélité
            <select [ngModel]="c.categorieClient" (ngModelChange)="changerCategorie($event)">
              @for (cat of categories; track cat) { <option [value]="cat">{{ cat }}</option> }
            </select>
          </label>
        </div>

        <div class="card">
          <h3>Éligibilité à la location</h3>
          @if (eligibilite(); as e) {
            <p class="big" [class.c-green]="e.eligible" [class.c-red]="!e.eligible">{{ e.eligible ? '✔ Éligible' : '✘ Non éligible' }}</p>
            <p>{{ e.message }}</p>
            <ul>
              <li>Âge : <b>{{ e.age }} ans</b> (minimum 21)</li>
              <li>Permis valide : <b>{{ e.permisValide ? 'oui' : 'non' }}</b></li>
            </ul>
          }
        </div>
      </section>

      <div class="card table-wrap">
        <h3>Historique des locations</h3>
        <table>
          <thead><tr><th>#</th><th>Véhicule</th><th>Du</th><th>Au (prévu)</th><th>Statut</th><th class="num">Montant</th></tr></thead>
          <tbody>
            @for (l of historique(); track l.id) {
              <tr>
                <td>{{ l.id }}</td>
                <td>{{ nomVehicule(l.vehiculeId) }}</td>
                <td>{{ l.dateDebut | date: 'dd/MM/yyyy' }}</td>
                <td>{{ l.dateFinPrevue | date: 'dd/MM/yyyy' }}</td>
                <td><span class="badge" [class]="'loc-' + l.statut">{{ l.statut }}</span></td>
                <td class="num">{{ l.montantTotal | number: '1.2-2' }} TND</td>
              </tr>
            } @empty { <tr><td colspan="6" class="muted">Aucune location.</td></tr> }
          </tbody>
        </table>
      </div>
    }
  `,
})
export class ClientDetail {
  private readonly clients = inject(ClientService);
  private readonly locations = inject(LocationService);
  private readonly vehicules = inject(VehiculeService);
  private readonly notifications = inject(NotificationService);
  private readonly id = Number(inject(ActivatedRoute).snapshot.paramMap.get('id'));

  protected readonly categories = CATEGORIES_CLIENT;
  protected readonly client = signal<Client | null>(null);
  protected readonly eligibilite = signal<Eligibilite | null>(null);
  protected readonly historique = signal<Location[]>([]);
  private readonly parc = signal<Vehicule[]>([]);

  constructor() {
    forkJoin({
      client: this.clients.get(this.id),
      eligibilite: this.clients.eligibilite(this.id),
      historique: this.locations.list({ clientId: this.id, size: 100 }),
      parc: this.vehicules.list(),
    }).subscribe((r) => {
      this.client.set(r.client);
      this.eligibilite.set(r.eligibilite);
      this.historique.set(r.historique.content);
      this.parc.set(r.parc);
    });
  }

  protected nomVehicule(id: number): string {
    const v = this.parc().find((x) => x.id === id);
    return v ? `${v.marque} ${v.modele}` : `#${id}`;
  }

  protected changerCategorie(categorie: CategorieClient): void {
    this.clients.changerCategorie(this.id, categorie).subscribe((c) => {
      this.client.set(c);
      this.notifications.success('Catégorie mise à jour');
    });
  }
}
