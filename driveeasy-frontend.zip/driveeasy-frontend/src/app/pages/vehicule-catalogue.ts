import { DecimalPipe } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { NotificationService } from '../core/notification';
import { Carburant, CARBURANTS, CATEGORIES_VEHICULE, CategorieVehicule, STATUTS_VEHICULE, StatutVehicule, Vehicule } from '../core/models';
import { VehiculeService } from '../core/vehicule.service';

const FALLBACK_IMG =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="250"><rect width="100%" height="100%" fill="#e5e7eb"/><text x="50%" y="50%" text-anchor="middle" fill="#6b7280" font-family="sans-serif" font-size="20">Pas d\'image</text></svg>');

@Component({
  selector: 'app-vehicule-catalogue',
  imports: [FormsModule, RouterLink, DecimalPipe],
  template: `
    <div class="page-head">
      <h1>Catalogue des véhicules</h1>
      <a class="btn btn-primary" routerLink="/vehicules/new">➕ Ajouter un véhicule</a>
    </div>

    <div class="card filters">
      <label>Carburant
        <select [ngModel]="carburant()" (ngModelChange)="carburant.set($event); load()">
          <option value="">Tous</option>
          @for (c of carburants; track c) { <option [value]="c">{{ c }}</option> }
        </select>
      </label>
      <label>Catégorie
        <select [ngModel]="categorie()" (ngModelChange)="categorie.set($event); load()">
          <option value="">Toutes</option>
          @for (c of categories; track c) { <option [value]="c">{{ c }}</option> }
        </select>
      </label>
      <label>Statut
        <select [ngModel]="statut()" (ngModelChange)="statut.set($event); load()">
          <option value="">Tous</option>
          @for (s of statuts; track s) { <option [value]="s">{{ s }}</option> }
        </select>
      </label>
      <label>Prix max (TND/jour)
        <input type="number" min="0" [ngModel]="prixMax()" (ngModelChange)="prixMax.set($event); load()" />
      </label>
      <label>Tri
        <select [ngModel]="tri()" (ngModelChange)="tri.set($event); page.set(0)">
          <option value="prix-asc">Prix croissant</option>
          <option value="prix-desc">Prix décroissant</option>
          <option value="marque">Marque (A–Z)</option>
          <option value="km">Kilométrage</option>
        </select>
      </label>
    </div>

    @if (chargement()) { <p class="muted">Chargement…</p> }
    <div class="cards-grid">
      @for (v of pageItems(); track v.id) {
        <article class="vcard">
          <img [src]="v.imageUrl || fallback" [alt]="v.marque + ' ' + v.modele" (error)="onImgError($event)" />
          <div class="vcard-body">
            <div class="vcard-title">
              <h3>{{ v.marque }} {{ v.modele }}</h3>
              <span class="badge" [class]="'st-' + v.statut">{{ v.statut }}</span>
            </div>
            <p class="muted">{{ v.immatriculation }} · {{ v.annee }} · {{ v.couleur }}</p>
            <p>{{ v.carburant }} · {{ v.boite }} · {{ v.nbPlaces }} places · {{ v.categorie }}</p>
            <p class="muted">{{ v.kilometrage | number }} km</p>
            <div class="vcard-foot">
              <strong class="price">{{ v.prixJournalier | number: '1.2-2' }} TND<small>/jour</small></strong>
              <span>
                <a class="btn btn-sm" [routerLink]="['/vehicules', v.id, 'edit']">Modifier</a>
                <button class="btn btn-sm btn-danger" (click)="supprimer(v)">Supprimer</button>
              </span>
            </div>
          </div>
        </article>
      } @empty {
        @if (!chargement()) { <p class="muted">Aucun véhicule ne correspond aux filtres.</p> }
      }
    </div>

    @if (totalPages() > 1) {
      <div class="pager">
        <button class="btn btn-sm" [disabled]="page() === 0" (click)="page.set(page() - 1)">← Précédent</button>
        <span>Page {{ page() + 1 }} / {{ totalPages() }}</span>
        <button class="btn btn-sm" [disabled]="page() >= totalPages() - 1" (click)="page.set(page() + 1)">Suivant →</button>
      </div>
    }
  `,
})
export class VehiculeCatalogue {
  private readonly api = inject(VehiculeService);
  private readonly notifications = inject(NotificationService);

  protected readonly carburants = CARBURANTS;
  protected readonly categories = CATEGORIES_VEHICULE;
  protected readonly statuts = STATUTS_VEHICULE;
  protected readonly fallback = FALLBACK_IMG;
  private readonly pageSize = 6;

  protected readonly carburant = signal<Carburant | ''>('');
  protected readonly categorie = signal<CategorieVehicule | ''>('');
  protected readonly statut = signal<StatutVehicule | ''>('');
  protected readonly prixMax = signal<number | null>(null);
  protected readonly tri = signal('prix-asc');
  protected readonly page = signal(0);
  protected readonly chargement = signal(false);
  private readonly vehicules = signal<Vehicule[]>([]);

  /** Tri côté client ; les filtres sont appliqués côté serveur. */
  private readonly tries = computed(() => {
    const list = [...this.vehicules()];
    switch (this.tri()) {
      case 'prix-desc': return list.sort((a, b) => b.prixJournalier - a.prixJournalier);
      case 'marque': return list.sort((a, b) => (a.marque + a.modele).localeCompare(b.marque + b.modele));
      case 'km': return list.sort((a, b) => a.kilometrage - b.kilometrage);
      default: return list.sort((a, b) => a.prixJournalier - b.prixJournalier);
    }
  });
  protected readonly totalPages = computed(() => Math.ceil(this.tries().length / this.pageSize));
  protected readonly pageItems = computed(() => this.tries().slice(this.page() * this.pageSize, (this.page() + 1) * this.pageSize));

  constructor() {
    this.load();
  }

  protected load(): void {
    this.chargement.set(true);
    this.page.set(0);
    this.api.list({ carburant: this.carburant(), categorie: this.categorie(), statut: this.statut(), prixMax: this.prixMax() })
      .subscribe({
        next: (list) => { this.vehicules.set(list); this.chargement.set(false); },
        error: () => this.chargement.set(false),
      });
  }

  protected supprimer(v: Vehicule): void {
    if (!confirm(`Supprimer ${v.marque} ${v.modele} (${v.immatriculation}) ?`)) return;
    this.api.delete(v.id).subscribe(() => {
      this.notifications.success('Véhicule supprimé');
      this.load();
    });
  }

  protected onImgError(event: Event): void {
    (event.target as HTMLImageElement).src = FALLBACK_IMG;
  }
}
