import { DecimalPipe } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { LocationService } from '../core/location.service';
import { Statistiques } from '../core/models';

@Component({
  selector: 'app-dashboard',
  imports: [DecimalPipe],
  template: `
    <h1>Tableau de bord</h1>
    @if (stats(); as s) {
      <section class="kpis">
        <div class="kpi"><span>Véhicules disponibles</span><strong class="c-green">{{ s.vehiculesDisponibles ?? '–' }}</strong></div>
        <div class="kpi"><span>Véhicules loués</span><strong class="c-orange">{{ s.vehiculesLoues ?? '–' }}</strong></div>
        <div class="kpi"><span>En maintenance</span><strong class="c-red">{{ s.vehiculesMaintenance ?? '–' }}</strong></div>
        <div class="kpi"><span>Chiffre d'affaires du mois</span><strong>{{ s.chiffreAffairesMois | number: '1.2-2' }} TND</strong></div>
        <div class="kpi"><span>Locations en cours</span><strong>{{ s.locationsEnCours }}</strong></div>
        <div class="kpi"><span>Taux d'occupation</span><strong>{{ s.tauxOccupation ?? '–' }} %</strong></div>
      </section>

      <section class="grid2">
        <div class="card">
          <h3>Répartition du parc</h3>
          <div class="donut-row">
            <div class="donut" [style.background]="donut()"><div class="donut-hole">{{ s.vehiculesTotal ?? 0 }}<small>véhicules</small></div></div>
            <ul class="legend">
              <li><i class="dot bg-green"></i> Disponibles : {{ s.vehiculesDisponibles ?? 0 }}</li>
              <li><i class="dot bg-orange"></i> Loués : {{ s.vehiculesLoues ?? 0 }}</li>
              <li><i class="dot bg-red"></i> Maintenance : {{ s.vehiculesMaintenance ?? 0 }}</li>
            </ul>
          </div>
        </div>

        <div class="card">
          <h3>Locations par statut</h3>
          @for (b of statutBars(); track b.label) {
            <div class="bar-row">
              <span class="bar-label">{{ b.label }}</span>
              <div class="bar-track"><div class="bar-fill" [style.width.%]="b.pct" [style.background]="b.color"></div></div>
              <b>{{ b.value }}</b>
            </div>
          }
        </div>
      </section>

      <section class="grid2">
        <div class="card">
          <h3>Véhicules les plus loués</h3>
          @for (b of topBars(); track b.label) {
            <div class="bar-row">
              <span class="bar-label">{{ b.label }}</span>
              <div class="bar-track"><div class="bar-fill" [style.width.%]="b.pct"></div></div>
              <b>{{ b.value }}</b>
            </div>
          } @empty { <p class="muted">Aucune donnée.</p> }
        </div>
        <div class="card">
          <h3>Chiffre d'affaires</h3>
          <p class="big">{{ s.chiffreAffairesTotal | number: '1.2-2' }} TND</p>
          <p class="muted">cumulé sur les locations terminées ({{ s.locationsTerminees }})</p>
          <p>Réservations en attente : <b>{{ s.locationsReservees }}</b> · Annulées : <b>{{ s.locationsAnnulees }}</b></p>
        </div>
      </section>
    } @else if (erreur()) {
      <div class="card">Impossible de charger les statistiques. Vérifiez que la gateway et les services sont démarrés.</div>
    } @else {
      <p class="muted">Chargement…</p>
    }
  `,
})
export class Dashboard {
  private readonly api = inject(LocationService);
  protected readonly stats = signal<Statistiques | null>(null);
  protected readonly erreur = signal(false);

  protected readonly donut = computed(() => {
    const s = this.stats();
    const total = s?.vehiculesTotal ?? 0;
    if (!s || total === 0) return 'var(--border)';
    const a = ((s.vehiculesDisponibles ?? 0) / total) * 100;
    const b = a + ((s.vehiculesLoues ?? 0) / total) * 100;
    return `conic-gradient(var(--green) 0 ${a}%, var(--orange) ${a}% ${b}%, var(--red) ${b}% 100%)`;
  });

  protected readonly statutBars = computed(() => {
    const s = this.stats();
    if (!s) return [];
    const rows = [
      { label: 'Réservées', value: s.locationsReservees, color: 'var(--blue)' },
      { label: 'En cours', value: s.locationsEnCours, color: 'var(--orange)' },
      { label: 'Terminées', value: s.locationsTerminees, color: 'var(--green)' },
      { label: 'Annulées', value: s.locationsAnnulees, color: 'var(--red)' },
    ];
    const max = Math.max(1, ...rows.map((r) => r.value));
    return rows.map((r) => ({ ...r, pct: (r.value / max) * 100 }));
  });

  protected readonly topBars = computed(() => {
    const top = this.stats()?.topVehicules ?? [];
    const max = Math.max(1, ...top.map((t) => t.nbLocations));
    return top.map((t) => ({
      label: t.marque ? `${t.marque} ${t.modele}` : `Véhicule #${t.vehiculeId}`,
      value: t.nbLocations,
      pct: (t.nbLocations / max) * 100,
    }));
  });

  constructor() {
    this.api.statistiques().subscribe({
      next: (s) => this.stats.set(s),
      error: () => this.erreur.set(true),
    });
  }
}
