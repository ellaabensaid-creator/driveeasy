import { DatePipe } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ClientService } from '../core/client.service';
import { Client } from '../core/models';

@Component({
  selector: 'app-client-list',
  imports: [FormsModule, RouterLink, DatePipe],
  template: `
    <h1>Clients</h1>
    <div class="card filters">
      <label class="grow">Recherche (nom, CIN, email)
        <input [ngModel]="recherche()" (ngModelChange)="rechercher($event)" placeholder="Ex. Ben Salah, 09876543, …" />
      </label>
    </div>

    <div class="card table-wrap">
      <table>
        <thead><tr><th>Nom</th><th>CIN</th><th>Email</th><th>Téléphone</th><th>Permis expire le</th><th>Catégorie</th><th></th></tr></thead>
        <tbody>
          @for (c of pageItems(); track c.id) {
            <tr>
              <td>{{ c.prenom }} {{ c.nom }}</td>
              <td>{{ c.cin }}</td>
              <td>{{ c.email }}</td>
              <td>{{ c.telephone }}</td>
              <td [class.err]="c.permisExpire">
                {{ c.dateExpirationPermis | date: 'dd/MM/yyyy' }}
                @if (c.permisExpire) { <span class="badge st-MAINTENANCE" title="Permis expiré">⚠ Permis expiré</span> }
              </td>
              <td><span class="badge" [class]="'cat-' + c.categorieClient">{{ c.categorieClient }}</span></td>
              <td><a class="btn btn-sm" [routerLink]="['/clients', c.id]">Fiche</a></td>
            </tr>
          } @empty {
            <tr><td colspan="7" class="muted">Aucun client trouvé.</td></tr>
          }
        </tbody>
      </table>
    </div>

    @if (totalPages() > 1) {
      <div class="pager">
        <button class="btn btn-sm" [disabled]="page() === 0" (click)="page.set(page() - 1)">← Précédent</button>
        <span>Page {{ page() + 1 }} / {{ totalPages() }}</span>
        <button class="btn btn-sm" [disabled]="page() >= totalPages() - 1" (click)="page.set(page() + 1)">Suivant →</button>
      </div>
    }
  `,
})
export class ClientList {
  private readonly api = inject(ClientService);
  private readonly pageSize = 8;
  protected readonly recherche = signal('');
  protected readonly page = signal(0);
  private readonly clients = signal<Client[]>([]);
  private timer: ReturnType<typeof setTimeout> | undefined;

  protected readonly totalPages = computed(() => Math.ceil(this.clients().length / this.pageSize));
  protected readonly pageItems = computed(() => this.clients().slice(this.page() * this.pageSize, (this.page() + 1) * this.pageSize));

  constructor() {
    this.charger();
  }

  /** Recherche avec léger délai (debounce) pour limiter les appels. */
  protected rechercher(valeur: string): void {
    this.recherche.set(valeur);
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.charger(), 300);
  }

  private charger(): void {
    this.page.set(0);
    this.api.list(this.recherche()).subscribe((list) => this.clients.set(list));
  }
}
