import { DatePipe, DecimalPipe } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { diffDays, today } from '../core/date-utils';
import { LocationService } from '../core/location.service';
import { NotificationService } from '../core/notification';
import { LocationDetail } from '../core/models';

/** Coefficient de pénalité : doit rester identique à driveeasy.location.penalite-coefficient (backend). */
const COEFF_PENALITE = 1.5;

@Component({
  selector: 'app-location-retour',
  imports: [FormsModule, DecimalPipe, DatePipe, RouterLink],
  template: `
    <a routerLink="/locations" class="muted no-print">← Retour aux locations</a>
    @if (detail(); as d) {
      <h1>{{ d.location.statut === 'TERMINEE' ? 'Récapitulatif de location' : 'Retour du véhicule' }} #{{ d.location.id }}</h1>

      <section class="grid2">
        <div class="card">
          <h3>Client</h3>
          <p><b>{{ d.client?.prenom }} {{ d.client?.nom }}</b> ({{ d.client?.categorieClient }})<br />{{ d.client?.email }} · {{ d.client?.telephone }}</p>
          <h3>Véhicule</h3>
          <p><b>{{ d.vehicule?.marque }} {{ d.vehicule?.modele }}</b><br />{{ d.vehicule?.immatriculation }}</p>
        </div>
        <div class="card">
          <h3>Location</h3>
          <dl class="dl">
            <dt>Début</dt><dd>{{ d.location.dateDebut | date: 'dd/MM/yyyy' }}</dd>
            <dt>Fin prévue</dt><dd>{{ d.location.dateFinPrevue | date: 'dd/MM/yyyy' }}</dd>
            <dt>Km au départ</dt><dd>{{ d.location.kmDepart | number }}</dd>
            <dt>Prix journalier appliqué</dt><dd>{{ d.location.prixJournalierApplique | number: '1.2-2' }} TND</dd>
          </dl>
        </div>
      </section>

      @if (d.location.statut === 'EN_COURS') {
        <div class="card no-print">
          <h3>Saisie du retour</h3>
          <div class="filters">
            <label>Kilométrage au retour
              <input type="number" [min]="d.location.kmDepart ?? 0" [ngModel]="kmRetour()" (ngModelChange)="kmRetour.set($event)" />
            </label>
            <label>Date de retour
              <input type="date" [min]="d.location.dateDebut" [ngModel]="dateRetour()" (ngModelChange)="dateRetour.set($event)" />
            </label>
          </div>
          @if (!kmValide()) { <p class="err">Le kilométrage de retour doit être ≥ {{ d.location.kmDepart }}.</p> }

          <table class="recap">
            <tr><td>Montant prévu</td><td>{{ d.location.montantTotal | number: '1.2-2' }} TND</td></tr>
            <tr><td>Jours de retard</td><td>{{ retard() }}</td></tr>
            <tr><td>Pénalité ({{ coeff }} × prix journalier × retard)</td><td>{{ penalite() | number: '1.2-2' }} TND</td></tr>
            <tr class="total"><td>Total à payer</td><td>{{ totalEstime() | number: '1.2-2' }} TND</td></tr>
          </table>
          <div class="actions"><button class="btn btn-primary" [disabled]="!kmValide() || occupe()" (click)="valider(d.location.id)">Valider le retour</button></div>
        </div>
      } @else if (d.location.statut === 'TERMINEE') {
        <div class="card">
          <h3>Récapitulatif final</h3>
          <table class="recap">
            <tr><td>Date de retour</td><td>{{ d.location.dateRetourEffectif | date: 'dd/MM/yyyy' }}</td></tr>
            <tr><td>Km au retour</td><td>{{ d.location.kmRetour | number }} ({{ (d.location.kmRetour ?? 0) - (d.location.kmDepart ?? 0) | number }} km parcourus)</td></tr>
            <tr><td>Pénalité de retard</td><td>{{ d.location.penalite | number: '1.2-2' }} TND</td></tr>
            <tr class="total"><td>Montant total</td><td>{{ d.location.montantTotal | number: '1.2-2' }} TND</td></tr>
          </table>
          <div class="actions no-print"><button class="btn btn-primary" (click)="imprimer()">🖨 Imprimer</button></div>
        </div>
      } @else {
        <div class="alert">Cette location est au statut {{ d.location.statut }} : aucun retour possible.</div>
      }
    }
  `,
})
export class LocationRetour {
  private readonly api = inject(LocationService);
  private readonly notifications = inject(NotificationService);
  private readonly id = Number(inject(ActivatedRoute).snapshot.paramMap.get('id'));

  protected readonly coeff = COEFF_PENALITE;
  protected readonly detail = signal<LocationDetail | null>(null);
  protected readonly kmRetour = signal(0);
  protected readonly dateRetour = signal(today());
  protected readonly occupe = signal(false);

  protected readonly kmValide = computed(() => this.kmRetour() >= (this.detail()?.location.kmDepart ?? 0));
  protected readonly retard = computed(() => {
    const l = this.detail()?.location;
    return l ? Math.max(0, diffDays(l.dateFinPrevue, this.dateRetour())) : 0;
  });
  protected readonly penalite = computed(() => {
    const l = this.detail()?.location;
    return l ? COEFF_PENALITE * l.prixJournalierApplique * this.retard() : 0;
  });
  protected readonly totalEstime = computed(() => (this.detail()?.location.montantTotal ?? 0) + this.penalite());

  constructor() {
    this.api.get(this.id).subscribe((d) => {
      this.detail.set(d);
      this.kmRetour.set(d.location.kmDepart ?? 0);
    });
  }

  protected valider(id: number): void {
    this.occupe.set(true);
    this.api.retour(id, this.kmRetour(), this.dateRetour()).subscribe({
      next: () => {
        this.notifications.success('Retour enregistré : véhicule de nouveau disponible');
        this.api.get(id).subscribe((d) => { this.detail.set(d); this.occupe.set(false); });
      },
      error: () => this.occupe.set(false),
    });
  }

  protected imprimer(): void {
    window.print();
  }
}
