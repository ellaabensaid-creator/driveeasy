import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { HasPendingChanges } from '../core/pending-changes.guard';
import { NotificationService } from '../core/notification';
import { Boite, BOITES, Carburant, CARBURANTS, CATEGORIES_VEHICULE, CategorieVehicule, STATUTS_VEHICULE, StatutVehicule, VehiculeRequest } from '../core/models';
import { VehiculeService } from '../core/vehicule.service';

@Component({
  selector: 'app-vehicule-form',
  imports: [ReactiveFormsModule, RouterLink],
  template: `
    <h1>{{ id ? 'Modifier le véhicule' : 'Nouveau véhicule' }}</h1>
    <form class="card form-grid" [formGroup]="form" (ngSubmit)="enregistrer()">
      <label>Immatriculation *
        <input formControlName="immatriculation" placeholder="123 TUN 4567" />
        @if (invalide('immatriculation')) { <small class="err">Obligatoire</small> }
      </label>
      <label>Marque *
        <input formControlName="marque" />
        @if (invalide('marque')) { <small class="err">Obligatoire</small> }
      </label>
      <label>Modèle *
        <input formControlName="modele" />
        @if (invalide('modele')) { <small class="err">Obligatoire</small> }
      </label>
      <label>Année * (1990 – {{ anneeMax }})
        <input type="number" formControlName="annee" />
        @if (invalide('annee')) { <small class="err">Année comprise entre 1990 et {{ anneeMax }}</small> }
      </label>
      <label>Couleur
        <input formControlName="couleur" />
      </label>
      <label>Carburant *
        <select formControlName="carburant">@for (c of carburants; track c) { <option [value]="c">{{ c }}</option> }</select>
      </label>
      <label>Boîte *
        <select formControlName="boite">@for (b of boites; track b) { <option [value]="b">{{ b }}</option> }</select>
      </label>
      <label>Catégorie *
        <select formControlName="categorie">@for (c of categories; track c) { <option [value]="c">{{ c }}</option> }</select>
      </label>
      <label>Nombre de places * (1 – 9)
        <input type="number" formControlName="nbPlaces" />
        @if (invalide('nbPlaces')) { <small class="err">Entre 1 et 9</small> }
      </label>
      <label>Kilométrage *
        <input type="number" formControlName="kilometrage" />
        @if (invalide('kilometrage')) { <small class="err">Doit être ≥ 0</small> }
      </label>
      <label>Prix journalier (TND) *
        <input type="number" step="0.5" formControlName="prixJournalier" />
        @if (invalide('prixJournalier')) { <small class="err">Doit être strictement positif</small> }
      </label>
      <label>Statut
        <select formControlName="statut">@for (s of statuts; track s) { <option [value]="s">{{ s }}</option> }</select>
      </label>
      <label class="span2">URL de l'image
        <input formControlName="imageUrl" placeholder="https://…" />
      </label>
      <div class="span2 actions">
        <a class="btn" routerLink="/vehicules">Annuler</a>
        <button class="btn btn-primary" type="submit" [disabled]="envoi()">{{ id ? 'Enregistrer' : 'Créer' }}</button>
      </div>
    </form>
  `,
})
export class VehiculeForm implements HasPendingChanges {
  private readonly fb = inject(FormBuilder);
  private readonly api = inject(VehiculeService);
  private readonly router = inject(Router);
  private readonly notifications = inject(NotificationService);

  protected readonly id = Number(inject(ActivatedRoute).snapshot.paramMap.get('id')) || null;
  protected readonly anneeMax = new Date().getFullYear();
  protected readonly carburants = CARBURANTS;
  protected readonly boites = BOITES;
  protected readonly categories = CATEGORIES_VEHICULE;
  protected readonly statuts = STATUTS_VEHICULE;
  protected readonly envoi = signal(false);
  private enregistre = false;

  protected readonly form = this.fb.nonNullable.group({
    immatriculation: ['', Validators.required],
    marque: ['', Validators.required],
    modele: ['', Validators.required],
    annee: [this.anneeMax, [Validators.required, Validators.min(1990), Validators.max(this.anneeMax)]],
    couleur: [''],
    carburant: ['ESSENCE' as Carburant, Validators.required],
    boite: ['MANUELLE' as Boite, Validators.required],
    nbPlaces: [5, [Validators.required, Validators.min(1), Validators.max(9)]],
    kilometrage: [0, [Validators.required, Validators.min(0)]],
    prixJournalier: [80, [Validators.required, Validators.min(0.01)]],
    statut: ['DISPONIBLE' as StatutVehicule],
    categorie: ['ECONOMIQUE' as CategorieVehicule, Validators.required],
    imageUrl: [''],
  });

  constructor() {
    if (this.id) {
      this.api.get(this.id).subscribe((v) => this.form.patchValue(v));
    }
  }

  hasPendingChanges(): boolean {
    return this.form.dirty && !this.enregistre;
  }

  protected invalide(name: keyof typeof this.form.controls): boolean {
    const c = this.form.controls[name];
    return c.invalid && (c.touched || c.dirty);
  }

  protected enregistrer(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const body = this.form.getRawValue() as VehiculeRequest;
    const requete = this.id ? this.api.update(this.id, body) : this.api.create(body);
    this.envoi.set(true);
    requete.subscribe({
      next: () => {
        this.enregistre = true;
        this.notifications.success(this.id ? 'Véhicule modifié' : 'Véhicule créé');
        this.router.navigate(['/vehicules']);
      },
      error: () => this.envoi.set(false),
    });
  }
}
