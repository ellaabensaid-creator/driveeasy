import { DecimalPipe } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ClientService } from '../core/client.service';
import { addDays, today } from '../core/date-utils';
import { LocationService } from '../core/location.service';
import { NotificationService } from '../core/notification';
import { Client, Eligibilite, Simulation, VehiculeLite } from '../core/models';

/** Assistant en 5 étapes : client → période → véhicule disponible → simulation du prix → confirmation. */
@Component({
  selector: 'app-location-wizard',
  imports: [FormsModule, DecimalPipe],
  template: `
    <h1>Nouvelle location</h1>
    <ol class="stepper">
      @for (s of etapes; track s; let i = $index) {
        <li [class.active]="step() === i + 1" [class.done]="step() > i + 1"><span>{{ i + 1 }}</span> {{ s }}</li>
      }
    </ol>

    <div class="card">
      @switch (step()) {
        @case (1) {
          <h3>1. Choisir le client</h3>
          <label>Client
            <select [ngModel]="clientId()" (ngModelChange)="choisirClient($event)">
              <option [ngValue]="null">— Sélectionner —</option>
              @for (c of clients(); track c.id) { <option [ngValue]="c.id">{{ c.prenom }} {{ c.nom }} (CIN {{ c.cin }}) – {{ c.categorieClient }}</option> }
            </select>
          </label>
          @if (eligibilite(); as e) {
            <p [class.c-green]="e.eligible" [class.c-red]="!e.eligible"><b>{{ e.eligible ? '✔ Client éligible' : '✘ Client non éligible' }}</b> – {{ e.message }}</p>
          }
        }
        @case (2) {
          <h3>2. Période de location</h3>
          <div class="filters">
            <label>Date de début <input type="date" [min]="aujourdhui" [ngModel]="dateDebut()" (ngModelChange)="dateDebut.set($event)" /></label>
            <label>Date de fin prévue <input type="date" [min]="dateDebut()" [ngModel]="dateFin()" (ngModelChange)="dateFin.set($event)" /></label>
          </div>
          @if (!periodeValide()) { <p class="err">La date de fin doit être postérieure à la date de début.</p> }
        }
        @case (3) {
          <h3>3. Véhicule disponible du {{ dateDebut() }} au {{ dateFin() }}</h3>
          <div class="cards-grid">
            @for (v of vehicules(); track v.id) {
              <article class="vcard selectable" [class.selected]="vehiculeId() === v.id" (click)="vehiculeId.set(v.id)">
                <div class="vcard-body">
                  <div class="vcard-title"><h3>{{ v.marque }} {{ v.modele }}</h3><span class="badge st-DISPONIBLE">{{ v.categorie }}</span></div>
                  <p class="muted">{{ v.immatriculation }} · {{ v.annee }} · {{ v.couleur }}</p>
                  <strong class="price">{{ v.prixJournalier | number: '1.2-2' }} TND<small>/jour</small></strong>
                </div>
              </article>
            } @empty { <p class="muted">Aucun véhicule disponible sur cette période.</p> }
          </div>
        }
        @case (4) {
          <h3>4. Simulation du prix</h3>
          @if (simulation(); as s) {
            <table class="recap">
              <tr><td>Durée</td><td>{{ s.jours }} jour(s)</td></tr>
              <tr><td>Prix journalier de base</td><td>{{ s.prixJournalierBase | number: '1.2-2' }} TND</td></tr>
              <tr><td>Coefficient catégorie ({{ s.categorieVehicule }})</td><td>× {{ s.coefficient }}</td></tr>
              <tr><td>Prix journalier appliqué</td><td>{{ s.prixJournalierApplique | number: '1.2-2' }} TND</td></tr>
              <tr><td>Remise fidélité ({{ s.categorieClient }})</td><td>− {{ s.remisePourcentage }} %</td></tr>
              <tr class="total"><td>Montant total</td><td>{{ s.montantTotal | number: '1.2-2' }} TND</td></tr>
            </table>
          }
        }
        @case (5) {
          <h3>5. Confirmation</h3>
          <dl class="dl">
            <dt>Client</dt><dd>{{ clientChoisi()?.prenom }} {{ clientChoisi()?.nom }}</dd>
            <dt>Véhicule</dt><dd>{{ vehiculeChoisi()?.marque }} {{ vehiculeChoisi()?.modele }} ({{ vehiculeChoisi()?.immatriculation }})</dd>
            <dt>Période</dt><dd>du {{ dateDebut() }} au {{ dateFin() }}</dd>
            <dt>Montant total</dt><dd><b>{{ simulation()?.montantTotal | number: '1.2-2' }} TND</b></dd>
          </dl>
        }
      }

      <div class="actions">
        <button class="btn" [disabled]="step() === 1" (click)="precedent()">← Précédent</button>
        @if (step() < 5) {
          <button class="btn btn-primary" [disabled]="!peutContinuer() || occupe()" (click)="suivant()">Suivant →</button>
        } @else {
          <button class="btn btn-primary" [disabled]="occupe()" (click)="confirmer()">✔ Confirmer la réservation</button>
        }
      </div>
    </div>
  `,
})
export class LocationWizard {
  private readonly clientsApi = inject(ClientService);
  private readonly api = inject(LocationService);
  private readonly router = inject(Router);
  private readonly notifications = inject(NotificationService);

  protected readonly etapes = ['Client', 'Période', 'Véhicule', 'Simulation', 'Confirmation'];
  protected readonly aujourdhui = today();
  protected readonly step = signal(1);
  protected readonly occupe = signal(false);

  protected readonly clients = signal<Client[]>([]);
  protected readonly clientId = signal<number | null>(null);
  protected readonly eligibilite = signal<Eligibilite | null>(null);
  protected readonly dateDebut = signal(today());
  protected readonly dateFin = signal(addDays(today(), 3));
  protected readonly vehicules = signal<VehiculeLite[]>([]);
  protected readonly vehiculeId = signal<number | null>(null);
  protected readonly simulation = signal<Simulation | null>(null);

  protected readonly clientChoisi = computed(() => this.clients().find((c) => c.id === this.clientId()));
  protected readonly vehiculeChoisi = computed(() => this.vehicules().find((v) => v.id === this.vehiculeId()));
  protected readonly periodeValide = computed(() => this.dateFin() > this.dateDebut() && this.dateDebut() >= this.aujourdhui);

  protected readonly peutContinuer = computed(() => {
    switch (this.step()) {
      case 1: return this.eligibilite()?.eligible === true;
      case 2: return this.periodeValide();
      case 3: return this.vehiculeId() !== null;
      case 4: return this.simulation() !== null;
      default: return true;
    }
  });

  constructor() {
    this.clientsApi.list().subscribe((list) => this.clients.set(list));
  }

  protected choisirClient(id: number | null): void {
    this.clientId.set(id);
    this.eligibilite.set(null);
    if (id !== null) this.clientsApi.eligibilite(id).subscribe((e) => this.eligibilite.set(e));
  }

  protected precedent(): void {
    this.step.update((s) => Math.max(1, s - 1));
  }

  protected suivant(): void {
    const clientId = this.clientId();
    switch (this.step()) {
      case 2: {
        // le permis doit rester valide jusqu'à la fin de la location
        if (clientId === null) return;
        this.occupe.set(true);
        this.clientsApi.eligibilite(clientId, this.dateFin()).subscribe({
          next: (e) => {
            this.eligibilite.set(e);
            if (!e.eligible) {
              this.notifications.error(`Client non éligible sur cette période : ${e.message}`);
              this.occupe.set(false);
              return;
            }
            this.api.vehiculesDisponibles(this.dateDebut(), this.dateFin()).subscribe({
              next: (list) => { this.vehicules.set(list); this.vehiculeId.set(null); this.occupe.set(false); this.step.set(3); },
              error: () => this.occupe.set(false),
            });
          },
          error: () => this.occupe.set(false),
        });
        return;
      }
      case 3: {
        const vehiculeId = this.vehiculeId();
        if (vehiculeId === null) return;
        this.occupe.set(true);
        this.api.simulate({ clientId: clientId ?? undefined, vehiculeId, dateDebut: this.dateDebut(), dateFinPrevue: this.dateFin() })
          .subscribe({
            next: (s) => { this.simulation.set(s); this.occupe.set(false); this.step.set(4); },
            error: () => this.occupe.set(false),
          });
        return;
      }
      default:
        this.step.update((s) => s + 1);
    }
  }

  protected confirmer(): void {
    const clientId = this.clientId();
    const vehiculeId = this.vehiculeId();
    if (clientId === null || vehiculeId === null) return;
    this.occupe.set(true);
    this.api.create({ clientId, vehiculeId, dateDebut: this.dateDebut(), dateFinPrevue: this.dateFin() }).subscribe({
      next: (l) => {
        this.notifications.success(`Réservation #${l.id} créée`);
        this.router.navigate(['/locations']);
      },
      error: () => this.occupe.set(false),
    });
  }
}
