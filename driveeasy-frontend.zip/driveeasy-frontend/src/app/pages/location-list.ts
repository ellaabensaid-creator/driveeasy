import { DatePipe, DecimalPipe } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { ClientService } from '../core/client.service';
import { LocationService } from '../core/location.service';
import { NotificationService } from '../core/notification';
import { Client, Location, Page, STATUTS_LOCATION, StatutLocation, Vehicule } from '../core/models';
import { VehiculeService } from '../core/vehicule.service';

@Component({
  selector: 'app-location-list',
  imports: [FormsModule, RouterLink, DatePipe, DecimalPipe],
  template: `
    <div class="page-head">
      <h1>Locations</h1>
      <a class="btn btn-primary" routerLink="/locations/new">➕ Nouvelle location</a>
    </div>

    <div class="card filters">
      <label>Statut
        <select [ngModel]="statut()" (ngModelChange)="statut.set($event); charger(0)">
          <option value="">Tous</option>
          @for (s of statuts; track s) { <option [value]="s">{{ s }}</option> }
        </select>
      </label>
      <label>Période : du
        <input type="date" [ngModel]="debut()" (ngModelChange)="debut.set($event); charger(0)" />
      </label>
      <label>au
        <input type="date" [ngModel]="fin()" (ngModelChange)="fin.set($event); charger(0)" />
      </label>
      <button class="btn btn-sm" (click)="reinitialiser()">Réinitialiser</button>
    </div>

    <div class="card table-wrap">
      <table>
        <thead><tr><th>#</th><th>Client</th><th>Véhicule</th><th>Du</th><th>Au (prévu)</th><th>Statut</th><th class="num">Montant</th><th>Actions</th></tr></thead>
        <tbody>
          @for (l of page().content; track l.id) {
            <tr>
              <td>{{ l.id }}</td>
              <td>{{ nomClient(l.clientId) }}</td>
              <td>{{ nomVehicule(l.vehiculeId) }}</td>
              <td>{{ l.dateDebut | date: 'dd/MM/yyyy' }}</td>
              <td>{{ l.dateFinPrevue | date: 'dd/MM/yyyy' }}</td>
              <td><span class="badge" [class]="'loc-' + l.statut">{{ l.statut }}</span></td>
              <td class="num">{{ l.montantTotal | number: '1.2-2' }} TND</td>
              <td class="actions-cell">
                @if (l.statut === 'RESERVEE') {
                  <button class="btn btn-sm btn-primary" (click)="demarrer(l)">Départ</button>
                  <button class="btn btn-sm btn-danger" (click)="annuler(l)">Annuler</button>
                }
                @if (l.statut === 'EN_COURS') {
                  <a class="btn btn-sm btn-primary" [routerLink]="['/locations', l.id, 'retour']">Retour</a>
                }
                @if (l.statut === 'TERMINEE') {
                  <a class="btn btn-sm" [routerLink]="['/locations', l.id, 'retour']">Récapitulatif</a>
                }
              </td>
            </tr>
          } @empty { <tr><td colspan="8" class="muted">Aucune location.</td></tr> }
        </tbody>
      </table>
    </div>

    @if (page().totalPages > 1) {
      <div class="pager">
        <button class="btn btn-sm" [disabled]="page().page === 0" (click)="charger(page().page - 1)">← Précédent</button>
        <span>Page {{ page().page + 1 }} / {{ page().totalPages }} ({{ page().totalElements }} locations)</span>
        <button class="btn btn-sm" [disabled]="page().page >= page().totalPages - 1" (click)="charger(page().page + 1)">Suivant →</button>
      </div>
    }
  `,
})
export class LocationList {
  private readonly api = inject(LocationService);
  private readonly clientsApi = inject(ClientService);
  private readonly vehiculesApi = inject(VehiculeService);
  private readonly notifications = inject(NotificationService);

  protected readonly statuts = STATUTS_LOCATION;
  protected readonly statut = signal<StatutLocation | ''>('');
  protected readonly debut = signal('');
  protected readonly fin = signal('');
  protected readonly page = signal<Page<Location>>({ content: [], page: 0, size: 8, totalElements: 0, totalPages: 0 });
  private readonly clients = signal<Client[]>([]);
  private readonly vehicules = signal<Vehicule[]>([]);

  constructor() {
    forkJoin({ c: this.clientsApi.list(), v: this.vehiculesApi.list() }).subscribe((r) => {
      this.clients.set(r.c);
      this.vehicules.set(r.v);
    });
    this.charger(0);
  }

  protected charger(page: number): void {
    this.api.list({ statut: this.statut(), dateDebut: this.debut(), dateFin: this.fin(), page, size: 8 })
      .subscribe((p) => this.page.set(p));
  }

  protected reinitialiser(): void {
    this.statut.set('');
    this.debut.set('');
    this.fin.set('');
    this.charger(0);
  }

  protected nomClient(id: number): string {
    const c = this.clients().find((x) => x.id === id);
    return c ? `${c.prenom} ${c.nom}` : `#${id}`;
  }

  protected nomVehicule(id: number): string {
    const v = this.vehicules().find((x) => x.id === id);
    return v ? `${v.marque} ${v.modele}` : `#${id}`;
  }

  protected demarrer(l: Location): void {
    this.api.depart(l.id).subscribe(() => {
      this.notifications.success(`Location #${l.id} démarrée : le véhicule est maintenant LOUE`);
      this.charger(this.page().page);
    });
  }

  protected annuler(l: Location): void {
    if (!confirm(`Annuler la réservation #${l.id} ?`)) return;
    this.api.annuler(l.id).subscribe(() => {
      this.notifications.success(`Réservation #${l.id} annulée`);
      this.charger(this.page().page);
    });
  }
}
