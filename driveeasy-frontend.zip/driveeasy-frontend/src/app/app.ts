import { Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { NotificationService } from './core/notification';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <aside class="sidebar">
      <div class="brand">🚗 DriveEasy</div>
      <nav>
        <a routerLink="/dashboard" routerLinkActive="active">📊 Tableau de bord</a>
        <a routerLink="/vehicules" routerLinkActive="active">🚙 Véhicules</a>
        <a routerLink="/clients" routerLinkActive="active">👤 Clients</a>
        <a routerLink="/locations" routerLinkActive="active" [routerLinkActiveOptions]="{ exact: true }">📋 Locations</a>
        <a routerLink="/locations/new" routerLinkActive="active">➕ Nouvelle location</a>
      </nav>
      <small class="muted">Espace agent d'agence</small>
    </aside>
    <main class="content"><router-outlet /></main>
    <div class="toasts no-print">
      @for (t of notifications.toasts(); track t.id) {
        <div class="toast" [class.toast-error]="t.type === 'error'" (click)="notifications.dismiss(t.id)">{{ t.message }}</div>
      }
    </div>
  `,
})
export class App {
  protected readonly notifications = inject(NotificationService);
}
